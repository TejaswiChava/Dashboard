import React from 'react';
import { BrowserRouter as Router } from "react-router-dom";
import Layout from '../src/SharedModules/Layout/Components/Layout';
import './App.scss';
import Chatbot from '../src/SharedModules/Layout/Components/Chatbot/Chatbot';

function App() {
  return (
    <>
    <Chatbot/>
    <Router>
      <Layout/>
    </Router>
    </>
  );
}

export default App;

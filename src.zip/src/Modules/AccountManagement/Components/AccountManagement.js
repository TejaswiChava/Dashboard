import React from 'react';

function AccountManagement () {
    return (
        <div>
            <h1>Account management</h1>
        </div>
    )
}

export default AccountManagement;
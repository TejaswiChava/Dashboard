import React from "react";
import { CardDeck, Card, Button } from 'react-bootstrap';
import { Line, Circle } from 'rc-progress';
import { CircularProgressbar } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import Projects from './Projects';
import '../Dashboard.scss';
import CustomPieChart from '../../../SharedModules/Charts/Components/CustomPieChart';
import CustomDoughnutChart from '../../../SharedModules/Charts/Components/CustomDoughnutChart';
import CustomStackedBarGraph from '../../../SharedModules/Charts/Components/CustomStackedBarGraph';
import TableComponent from '../../../SharedModules/Table/Components/Table';

// function createData(name, calories, fat, carbs, protein) {
//     return { name, calories, fat, carbs, protein };
//   }
  
//   const rows = [
//     createData('Cupcake', 305, 3.7, 67, 4.3),
//     createData('Donut', 452, 25.0, 51, 4.9),
//     createData('Eclair', 262, 16.0, 24, 6.0),
//     createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
//     createData('Gingerbread', 356, 16.0, 49, 3.9),
//     createData('Honeycomb', 408, 3.2, 87, 6.5),
//     createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
//     createData('Jelly Bean', 375, 0.0, 94, 0.0),
//     createData('KitKat', 518, 26.0, 65, 7.0),
//     createData('Lollipop', 392, 0.2, 98, 0.0),
//     createData('Marshmallow', 318, 0, 81, 2.0),
//     createData('Nougat', 360, 19.0, 9, 37.0),
//     createData('Oreo', 437, 18.0, 63, 4.0),
//   ];
//   const headCells = [
//     { id: 'name', numeric: false, disablePadding: true, label: 'Dessert (100g serving)' },
//     { id: 'calories', numeric: true, disablePadding: false, label: 'Calories' },
//     { id: 'fat', numeric: true, disablePadding: false, label: 'Fat (g)', isProgress: true },
//     { id: 'carbs', numeric: true, disablePadding: false, label: 'Carbs (g)' },
//     { id: 'protein', numeric: true, disablePadding: false, label: 'Protein (g)' },
//   ];
const projects = [{
    country: 'FSS',
    area: 12
  }, {
    country: 'Eligiblity',
    area: 7
  }, {
    country: 'RXD',
    area: 7
  }, {
    country: 'SLR',
    area: 7
  }, {
    country: 'EDI',
    area: 6
  }, {
    country: 'CWP',
    area: 5
  }, {
    country: 'GHS Infra',
    area: 2
  }, {
    country: 'Maven',
    area: 55
  }];
   const technologies = [{
    language: 'React',
    percent: 40
  },   {
    language: '.NET',
    percent: 30
  },
  {
    language: 'JAVA',
    percent: 30
  }];
  export const effortTrend = [{
    state: 'GHS',
    completed: 500,
    remaining: 300
  }, {
    state: 'Non-GHS',
    completed: 700,
    remaining: 250
  }, {
    state: 'Payments',
    completed: 300,
    remaining: 600
  }];
function createData(name, manager, cluster, startDate, progress) {
    return { name, manager, cluster, startDate, progress };
  }
  
  const rows = [
    createData('FSS', 'John Doe', 'GHS', '01/01/2016', 25),
    createData('SLR', 'Bob Frapples', 'GHS', '01/01/2015',  51.0),
    createData('EDI', 'Anna Mul', 'Non-GHS', '01/01/2016', 90.0),
    createData('CWP', 'Paige Turner', 'GHS', '01/01/2016', 40.0),
    createData('Maven', 'Mary Jane', 'Non-GHS', '01/01/2016', 35.0)
  ];
  const headCells = [
    { id: 'name', numeric: false, disablePadding: true, label: 'Project' },
    { id: 'manager', numeric: false, disablePadding: false, label: 'Project Manager' },
    { id: 'cluster', numeric: false, disablePadding: false, label: 'Cluster' },
    { id: 'startDate', numeric: true, disablePadding: false, label: 'Start Date', isdate: true },
    // { id: 'endtDate', numeric: true, disablePadding: false, label: 'End Date', isdate: true },
    { id: 'progress', numeric: true, disablePadding: false, label: 'Progress(%)', isProgress: true },
  ];

export default function Dashboard() {
    return (
    <>
        <div className='container-fluid'>
            <div className='p-3'>
                <h2>Projects Dashboard</h2>
            </div>
        </div>
        <div id='projectsDashboard' className='container-fluid'>
            {/* <h2>Projects Dashboard</h2> */}
            <section id='portfolioStatus' className='row mx-0'>
                <div className='col'>
                    <div className='card status-box'>
                        <h3 className='p-2'>Planning</h3>
                        <CircularProgressbar value={80} text={`80%`} />
                    </div>
                </div>
                <div className='col-lg-3 col-md-6 mt-5 mt-md-0'>
                    <div className='card status-box'>
                        <h3 className='p-2'>Design</h3>
                        <CircularProgressbar value={50} text={`50%`} />
                    </div>
                </div>
                <div className='col-lg-3 col-md-6 mt-5 mt-lg-0'>
                    <div className='card status-box'>
                        <h3 className='p-2'>Development</h3>
                        <CircularProgressbar value={90} text={`90%`} />
                    </div>
                </div>
                <div className='col-lg-3 col-md-6 mt-5 mt-lg-0'>
                    <div className='card status-box'>
                        <h3 className='p-2'>Testing</h3>
                        <CircularProgressbar value={30} text={`30%`} />
                    </div>
                </div>
            </section>
            <section className='row mx-0'>
                <div className='col-2'>
                    {/* <div className='col-lg-3 col-md-6'> */}
                        <div className='my-1 card status-box text-center'>
                            {/* <AssignmentIcon className='icon' /> */}
                            <h1 className='p-2'>20</h1>
                            <h5>Projects</h5>
                        </div>
                    {/* </div> */}
                    <div className='my-1 card status-box text-center'>
                            {/* <AssignmentIcon className='icon' /> */}
                            <h1 className='p-2'>50</h1>
                            <h5>Technologies</h5>
                        </div>
                        <div className='my-1 card status-box text-center'>
                            {/* <AssignmentIcon className='icon' /> */}
                            <h1 className='p-2'>200</h1>
                            <h5>Resources</h5>
                        </div>
                        <div className='my-1 card status-box text-center'>
                            {/* <AssignmentIcon className='icon' /> */}
                            <h1 className='p-2'>130</h1>
                            <h5>Documents</h5>
                        </div>
                </div>
                <div className='col'>
                    <div className='row mx-0'>
                        <div className='col'>
                            <CustomPieChart dataSource={projects} title="Projects Count"/>
                        </div>
                        <div className='col'>
                            <CustomStackedBarGraph dataSource={effortTrend} title="Effort Trend" />
                        </div>
                        <div className='col'>
                            <CustomDoughnutChart dataSource={technologies} title="Technologies Used" />
                        </div>
                    </div>
                </div>
                
            </section>
        <TableComponent tableData={rows} headCells={headCells} />

        </div>

    </>
    )
}
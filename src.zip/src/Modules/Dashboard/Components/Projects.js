import React from "react";
import { CardDeck, Card, Button } from 'react-bootstrap';
import TopNavigation from "../../../SharedModules/Layout/Components/TopNavigation";
import '../Dashboard.scss';

export default function Projects() {
    return (
    <>
        <CardDeck className='m-3'>
            <a type='button' className='card'>
                <Card.Body>
                <Card.Title>GHS FSS</Card.Title>
                <Card.Text>
                    Manager: Sandeep Kumar Biswal
                </Card.Text>
                <Card.Text>
                    This is a wider card with supporting text below as a natural lead-in to
                    additional content. This content is a little bit longer.
                </Card.Text>
                </Card.Body>
                <Card.Footer>
                <small className="text-muted">Ongoing Efforts: 432hrs</small>
                </Card.Footer>
            </a>
            <a type='button' className='card'>
                <Card.Body>
                <Card.Title>ND PBM</Card.Title>
                <Card.Text>
                    Manager: Nitin Kamath
                </Card.Text>
                <Card.Text>
                    This card has supporting text below as a natural lead-in to additional
                    content.{' '}
                </Card.Text>
                </Card.Body>
                <Card.Footer>
                <small className="text-muted">Ongoing Efforts: 186hrs</small>
                </Card.Footer>
            </a>
            <a type='button' className='card'>
                <Card.Body>
                <Card.Title>HSP AMP</Card.Title>
                <Card.Text>
                    Manager: Suresh Katta
                </Card.Text>
                <Card.Text>
                    This is a wider card with supporting text below as a natural lead-in to
                    additional content. This card has even longer content than the first to
                    show that equal height action.
                </Card.Text>
                </Card.Body>
                <Card.Footer>
                <small className="text-muted">Ongoing Efforts: 110hrs</small>
                </Card.Footer>
            </a>
            <a type='button' className='card'>
                <Card.Body>
                <Card.Title>SLR</Card.Title>
                <Card.Text>
                    Manager: Nitin Kamath
                </Card.Text>
                <Card.Text>
                    This is a dummy text.
                </Card.Text>
                </Card.Body>
                <Card.Footer>
                <small className="text-muted">Ongoing Efforts: 200hrs</small>
                </Card.Footer>
            </a>
        </CardDeck>
        {/* <div className='container-fluid'>
            <div className='row'>
                <div class='col-md-12 col-lg-6'>
                    <div class="col-md-6">
                        <Card>
                            <Card.Body>
                            <Card.Title>GHS FSS</Card.Title>
                            <Card.Text>
                                Manager: Sandeep Kumar Biswal
                            </Card.Text>
                            <Card.Text>
                                This is a wider card with supporting text below as a natural lead-in to
                                additional content. This content is a little bit longer.
                            </Card.Text>
                            </Card.Body>
                            <Card.Footer>
                            <small className="text-muted">Ongoing Efforts: 432hrs</small>
                            </Card.Footer>
                        </Card>
                    </div>
                    <div className='col-md-6'>
                        <Card>
                            <Card.Body>
                            <Card.Title>ND PBM</Card.Title>
                            <Card.Text>
                                Manager: Nitin Kamath
                            </Card.Text>
                            <Card.Text>
                                This card has supporting text below as a natural lead-in to additional
                                content.{' '}
                            </Card.Text>
                            </Card.Body>
                            <Card.Footer>
                            <small className="text-muted">Ongoing Efforts: 186hrs</small>
                            </Card.Footer>
                        </Card>
                    </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    
                </div>
            </div>
            <div className='row'>
                <div class="col-md-12 col-lg-6">

                </div>
                <div class="col-md-12 col-lg-6">
                    
                </div>
            </div>
        </div> */}
    </>
    )
}
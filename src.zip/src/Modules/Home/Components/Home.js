import React from "react";
import '../Home.scss';
import { CardDeck, Card, Button, Overlay, Accordion } from 'react-bootstrap';
import CustomCarousel from '../../../SharedModules/Layout/Components/CustomCarousel';
// import Projects from '../../Dashboard/Components/Projects';
import PersonIcon from '@material-ui/icons/Person';
import EmojiEventsIcon from '@material-ui/icons/EmojiEvents';
import LocalLibraryOutlinedIcon from '@material-ui/icons/LocalLibraryOutlined';
import DvrIcon from '@material-ui/icons/Dvr';
import AssignmentIcon from '@material-ui/icons/Assignment';
import AttachMoneyIcon from '@material-ui/icons/AttachMoney';
import ArrowRightAltIcon from '@material-ui/icons/ArrowRightAlt';
import DoubleArrowIcon from '@material-ui/icons/DoubleArrow';
import TopNavigation from '../../../SharedModules/Layout/Components/TopNavigation';
import {Link} from 'react-router-dom';

export default function Home() {
    const [isLoggedin, setIsLoggedin] = React.useState(false);
    return (
    <>
    <TopNavigation isLoggedin = {isLoggedin}/>
    {/* <CustomCarousel/> */}
        <section id='hero' className='d-flex' 
        // style={{background: 'url(./hero3.jpg) top right', backgroundSize: 'cover' }} 
        >
            
            <div className='container px-sm-0'>
                <h1 className='display-4 text-right'>One stop shop </h1>
                <h1 className='display-4 text-right'>for all your project needs</h1>
                <h5 className='text-right'>Track progress, manage resources, identify 
                    risks and forecast future needs</h5>
                   <h5 className='text-right'> Empowering you to plan better 
                    and improve decision making</h5>
            </div>
        </section>        
        <main id='main'>            
            <section id='about-us'>
                <div className='container px-sm-0'>
                    <div className='row my-3'>
                        <div className='col-sm-4 d-flex align-items-stretch'>
                            <Link  to="/projectDashboard" className="linkStyle">
                                <div className='content'>
                                    <h3 className='pb-2'>Project Management</h3>
                                    <p>Track project status and draft plans for risk mitigation.</p>
                                    <p>Helps tailor processes to achieve seamless and successful deliveries.</p>
                                    <p>View upcoming projects in pipeline and help plan demands and resource allocation.</p>
                                </div>
                            </Link>
                        </div>
                        <div className='col-sm-8 d-flex align-items-stretch'>
                            <div className='icon-boxes d-flex flex-column justify-content-center'>
                                <div className='row'>
                                    <div className='col-lg-4 d-flex align-items-stretch'>
                                        <Link  to="/knowledgeManagement" className="linkStyle">
                                            <div className='icon-box mt-4 mt-xl-0'>
                                                <h4>Knowledge Management</h4>
                                                <p>Access different 
                                                    technical and domain related documents at account level and project level.</p>
                                            </div>
                                        </Link>
                                    </div>
                                    <div className='col-lg-4 d-flex align-items-stretch'>
                                        <Link  to="/talentManagement" className="linkStyle">
                                            <div className='icon-box mt-4 mt-xl-0'>
                                                <h4>Talent Management</h4>
                                                <p>Manage talents and plan upskilling needs across the organization. </p>
                                            </div>
                                        </Link>
                                    </div>
                                    <div className='col-lg-4 d-flex align-items-stretch'>
                                        <Link  to="/reportManagement" className="linkStyle">
                                            <div className='icon-box mt-4 mt-xl-0'>
                                                <h4>Report<br/> Creation</h4>
                                                <p>Automate generation of status reports on the click of a mouse.</p>
                                            </div>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        
            <section id='counts'>
                <div className='container-fluid'>
                    <div className='row'>
                        <div className='col-lg-3 col-md-6'>
                            <div className='card count-box'>
                                <AssignmentIcon className='icon' />
                                <h1 className='p-2'>20</h1>
                                <h5>Projects</h5>
                            </div>
                        </div>
                        <div className='col-lg-3 col-md-6 mt-5 mt-md-0'>
                            <div className='card count-box'>
                                <PersonIcon className='icon' />
                                <h1 className='p-2'>100</h1>
                                <h5>Employees</h5>
                            </div>
                        </div>
                        <div className='col-lg-3 col-md-6 mt-5 mt-lg-0'>
                            <div className='card count-box'>
                                <LocalLibraryOutlinedIcon className='icon' />
                                <h1 className='p-2'>50+</h1>
                                <h5>Agile Certified Professionals</h5>
                            </div>
                        </div>
                        <div className='col-lg-3 col-md-6 mt-5 mt-lg-0'>
                            <div className='card count-box'>
                                <DvrIcon className='icon' />
                                <h1 className='p-2'>20+</h1>
                                <h5>Technologies</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id='awards'>
                <div className='awards-header text-center'>
                    <EmojiEventsIcon/>
                    <h1>Achievements</h1>
                </div>
                <div className='container'>
                    <div className='card'>
                        <div className='card-img-box'>
                            <img className="card-img-top" src="./woman1.jpg" alt="woman 1"/>
                        </div>
                        <div className="card-body">
                            <h2>Mary John</h2>
                            <p className="card-text">Mary has been awarded as Performer of the year.</p>
                        </div>
                    </div>
                    <div className='card'>
                        <div className='card-img-box'>
                            <img className="card-img-top" src="./man1.jpg" alt="man 1"/>
                        </div>
                        <div className="card-body">
                            <h2>John Doe</h2>
                            <p className="card-text">People's manager of the year award goes to John.</p>
                        </div>
                    </div>
                    <div className='card'>
                        <div className='card-img-box'>
                            <img className="" src="./man2.jpg" alt="man 1"/>
                        </div>
                        <div className="card-body">
                            <h2>Robert Williams</h2>
                            <p className="card-text">He has been awarded the best manager award in conduent.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section id='news'>
                <div className='container'>
                    <div className='row'>
                        <div className='col-xl-7 col-lg-7 col-12'>
                            <section className='event-section'>
                                <div className='row'>
                                    <div className='col-lg py-1'>
                                        <img className='d-block w-100' src='./event1.jpg'/>
                                    </div>
                                    <div className='col-lg py-1'>
                                        <img className='d-block w-100' src='./event2.jpg'/>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='event-header'>
                                        <h1>Events</h1>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='col-lg py-1'>
                                        <img className='d-block w-100' src='./event2.jpg'/>
                                    </div>
                                    <div className='col-lg py-1'>
                                        <img className='d-block w-100' src='./event1.jpg'/>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <div className='col-xl-5 col-lg-5 col-12'>
                            <section className='news-section'>
                                <h1>In the news</h1>
                                <div className='news-row'>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit
                                </div>
                                <div className='news-row'>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do 
                                </div>
                                <div className='news-row'>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing
                                </div>
                                <div className='news-row'>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                                </div>
                                <div className='news-row'>
                                    <Link  to="/eventsNews" style={{textDecoration:'none'}}>See All<DoubleArrowIcon/></Link>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </>
    )
}
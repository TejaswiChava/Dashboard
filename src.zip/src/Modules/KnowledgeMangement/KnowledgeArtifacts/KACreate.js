import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import { Link } from 'react-router-dom';
import DescriptionIcon from '@material-ui/icons/Description';
import Typography from '@material-ui/core/Typography';
import Carousel from 'react-material-ui-carousel';
import { Paper } from '@material-ui/core';
import Rating from '@material-ui/lab/Rating'
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import SearchIcon from '@material-ui/icons/Search';
import InputBase from '@material-ui/core/InputBase';
import IconButton from '@material-ui/core/IconButton';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus, faRedo } from '@fortawesome/free-solid-svg-icons';
import Timeline from '@material-ui/lab/Timeline';
import TimelineItem from '@material-ui/lab/TimelineItem';
import TimelineSeparator from '@material-ui/lab/TimelineSeparator';
import TimelineConnector from '@material-ui/lab/TimelineConnector';
import TimelineContent from '@material-ui/lab/TimelineContent';
import TimelineDot from '@material-ui/lab/TimelineDot';
import TimelineOppositeContent from '@material-ui/lab/TimelineOppositeContent';
import PieChart, {
    Legend,
    Export,
    Series,
    Label,
    Font,
    Connector
} from 'devextreme-react/pie-chart';
// reactstrap components
import {
    Card,
    CardHeader,
    CardBody,
    NavItem,
    NavLink,
    Nav,
    TabContent,
    TabPane,
    Container,
    Row,
    Col,
} from "reactstrap";
import { CardContent } from '@material-ui/core';
function customizeText(arg) {
    return `${arg.valueText} (${arg.percentText})`;
}

const useStyles = makeStyles((theme) => ({
    root: {
        padding: '2px 4px',
        display: 'flex',
        alignItems: 'center',
        width: '100%'
    },
    input: {
        marginLeft: theme.spacing(1),
        flex: 1,
    },
    iconButton: {
        padding: 10,
    },
    divider: {
        height: 28,
        margin: 4,
    },
}));
export default function KnowledgeMangementCreate(props) {

    const classes = useStyles();
    return (
        <>
            <Container>
                <Row className="pb-3 pt-3">
                    <Col className="ml-auto mr-auto mb-4" md="10" xl="8">
                        <Card className="minimizedCard">

                            <CardContent>
                                <h4>Create an Artifact</h4>
                                <hr className="mt-1 mb-2" style={{ boxShadow: '0px 3px 0px 2px #116466' }}></hr>
                                <div style={{ width: '40%' }}>
                                    <TextField
                                        select
                                        id="standard-lob"
                                        fullWidth
                                        label="Type of Artifact"
                                        required
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                    >
                                        <MenuItem
                                            selected
                                            key={"Please Select One"}
                                            value={"Please Select One"}
                                        >
                                            {"Please Select One"}
                                        </MenuItem>
                                        <MenuItem
                                            selected
                                            key={"Project Related"}
                                            value={"Project Related"}
                                        >
                                            {'Project Related'}
                                        </MenuItem>
                                        <MenuItem
                                            selected
                                            key={"Technical Related"}
                                            value={"Technical Related"}
                                        >
                                            {'Technical Related'}
                                        </MenuItem>
                                        <MenuItem
                                            selected
                                            key={"Non-Technical Related"}
                                            value={"Non-Technical Related"}
                                        >
                                            {'Non-Technical Related'}
                                        </MenuItem>
                                        <MenuItem
                                            selected
                                            key={"Code Base"}
                                            value={"Code Base"}
                                        >
                                            {'Code Base'}
                                        </MenuItem>

                                    </TextField>
                                </div>
                                <div className="pb-2 pt-2 KACreate">
                                    <TextField
                                        id="outlined-multiline-static"
                                        label="Title"
                                        multiline
                                        inputProps={{ maxLength: 30 }}
                                        variant="outlined"
                                    />
                                </div>
                                <div className="pb-2 pt-2 KACreate">
                                    <TextField
                                        id="outlined-multiline-static"
                                        label="Authors"
                                        multiline
                                        inputProps={{ maxLength: 30 }}
                                        variant="outlined"
                                    />
                                </div>
                                <div className="pb-2 pt-2 KACreate">
                                    <TextField
                                        id="outlined-multiline-static"
                                        label="Attachments"
                                        type="file"
                                        inputProps={{ maxLength: 30 }}
                                        variant="outlined"
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                    />
                                </div>
                                <div className="pb-2 pt-2 KACreate">
                                    <TextField
                                        id="outlined-multiline-static"
                                        label="Description"
                                        multiline
                                        inputProps={{ maxLength: 30 }}
                                        variant="outlined"
                                        rows={7}
                                    />
                                </div>
                                <Row className="pl-2 pr-2 mt-2">
                                    <Col>
                                        <Button className="mr-2" variant="contained" color="success" style={{
                                            color: 'white',
                                            backgroundColor: '#116466',
                                            borderRadius: '41px'
                                        }}>
                                            <FontAwesomeIcon icon={faRedo} className='ml-1 mr-1' />
                                            Reset
                    </Button>
                                        <Button variant="contained" color="success" style={{
                                            color: 'white',
                                            backgroundColor: '#116466',
                                            borderRadius: '41px'
                                        }}>
                                            <FontAwesomeIcon icon={faPlus} className='ml-1 mr-1' />
                                            Create
                    </Button>
                                    </Col>
                                </Row>
                            </CardContent>
                        </Card>
                    </Col>
                    <Col className="ml-auto mr-auto" md="10" xl="4">
                        <Card className="minimizedCard">

                            <CardContent>
                                <h6>Related Artifacts</h6>
                                <hr className="mt-1 mb-2" style={{ boxShadow: '0px 3px 0px 2px #116466' }}></hr>
                                <ul className="lists_cards">
                                    <li><Link>View the Documentation Format</Link></li>
                                    <li><Link>Artifact etiquettes</Link></li>
                                    <li><Link>Project Documents</Link></li>
                                    <li><Link>Sample Creation Video</Link></li>
                                </ul>
                            </CardContent>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </>
    )
}
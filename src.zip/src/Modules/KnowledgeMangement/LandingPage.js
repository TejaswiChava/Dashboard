import React from 'react';
// import IndexNavbar from '../NavigationMenu';
import { makeStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import { Link } from 'react-router-dom';
import DescriptionIcon from '@material-ui/icons/Description';
import Typography from '@material-ui/core/Typography';
import Carousel from 'react-material-ui-carousel';
import { Paper } from '@material-ui/core';
import Rating from '@material-ui/lab/Rating'
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import SearchIcon from '@material-ui/icons/Search';
import InputBase from '@material-ui/core/InputBase';
import IconButton from '@material-ui/core/IconButton';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import Timeline from '@material-ui/lab/Timeline';
import TimelineItem from '@material-ui/lab/TimelineItem';
import TimelineSeparator from '@material-ui/lab/TimelineSeparator';
import TimelineConnector from '@material-ui/lab/TimelineConnector';
import TimelineContent from '@material-ui/lab/TimelineContent';
import TimelineDot from '@material-ui/lab/TimelineDot';
import CustomPieChart from '../../SharedModules/Charts/Components/CustomPieChart';
import TimelineOppositeContent from '@material-ui/lab/TimelineOppositeContent';
import PieChart, {
  Legend,
  Export,
  Series,
  Label,
  Font,
  Connector
} from 'devextreme-react/pie-chart';
// reactstrap components
import {
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  NavItem,
  NavLink,
  Nav,
  TabContent,
  TabPane,
  Container,
  Row,
  Col,
} from "reactstrap";
import { CardContent } from '@material-ui/core';
import TableComponent from '../../../src/SharedModules/Table/Components/Table';
import './knowledge.scss';
function customizeText(arg) {
  return `${arg.valueText} (${arg.percentText})`;
}
function Item(props) {
  return (
    <div className="wx-100"
      style={{
        backgroundImage: "url(" + require(props.item.imgUrl) + ")",
      }}
    >
      <h2>{props.item.name}</h2>
      <p>{props.item.description}</p>

      <Button className="CheckButton">
        Check it out!
            </Button>
    </div>
  )
}

const useStyles = makeStyles((theme) => ({
  root: {
    padding: '2px 4px',
    display: 'flex',
    alignItems: 'center',
    width: '100%'
  },
  input: {
    marginLeft: theme.spacing(1),
    flex: 1,
  },
  iconButton: {
    padding: 10,
  },
  divider: {
    height: 28,
    margin: 4,
  },
}));
export default function KnowledgeMangement(props) {
  var items = [
    {
      name: "Quiz Competetion",
      description: "Participate and Win exciting goodies",
      imgUrl: "./images"
    },
    {
      name: "Hackathon",
      description: "Provide a solution for a realtime Problem",
      imgUrl: './hackathon.png'
    },
    {
      name: "React Session",
      description: "Book you seat for learning React JS",
      imgUrl: './training.png'
    }
  ]
  const classes = useStyles();
  return (
    <>
      <div className='container-fluid'>
        <div className='p-3'>
          <h2>Knowledge Management</h2>
        </div>
      </div>
      <div id='knowledgeDashboard'>
        <section className='container-fluid'>
          <Row>
            <Col className="ml-auto mr-auto" md="10" xl="4">
              <Card>
                <Row>
                  <Col className="ml-auto mr-auto" >
                    <PieChart id="pie"
                      palette="soft pastel"
                      title="Knowledge Artifacts"
                      dataSource={[{
                        country: 'Project Docx',
                        area: 12
                      }, {
                        country: 'Multimedia',
                        area: 8
                      }, {
                        country: 'Videos',
                        area: 10
                      }, {
                        country: 'Code Bases',
                        area: 10
                      }, {
                        country: 'Others',
                        area: 55
                      }]}
                    >
                      <Legend
                        orientation="horizontal"
                        itemTextPosition="right"
                        horizontalAlignment="center"
                        verticalAlignment="bottom"
                      />
                      <Series argumentField="country" valueField="area">
                        <Label
                          visible={true}>
                          <Font size={13} />
                          <Connector visible={true} width={0.5} />
                        </Label>
                      </Series>
                    </PieChart>
                  </Col>
                </Row>
                <Row className="px-2 mt-2">
                  <Col>
                    <Button style={{
                      width: '8rem',
                      color: 'white',
                      backgroundColor: 'slategray',
                      borderRadius: '5px'
                    }}>
                      View More
                    </Button>
                  </Col>
                  <Col>
                    <Button variant="contained" color="success" style={{
                      color: 'white',
                      backgroundColor: 'slategray',
                      borderRadius: '5px'
                    }}>
                      <FontAwesomeIcon icon={faPlus} className='ml-1 mr-1' />
                      Create
                    </Button>
                  </Col>
                </Row>
              </Card>
            </Col>
            <Col className="ml-auto mr-auto" md="10" xl="4">
              <Card>
                <Row>
                  <Col className="ml-auto mr-auto" >
                    <PieChart id="pie"
                      palette="soft pastel"
                      title="Forums"
                      dataSource={[{
                        country: 'Opened',
                        area: 12
                      }, {
                        country: 'Closed',
                        area: 6
                      }, {
                        country: 'Comments',
                        area: 18
                      }, {
                        country: 'Public',
                        area: 9
                      }, {
                        country: 'Others',
                        area: 43
                      }]}
                    >
                      <Legend
                        orientation="horizontal"
                        itemTextPosition="right"
                        horizontalAlignment="center"
                        verticalAlignment="bottom"
                      />
                      <Series argumentField="country" valueField="area">
                        <Label
                          visible={true}>
                          <Font size={13} />
                          <Connector visible={true} width={0.5} />
                        </Label>
                      </Series>
                    </PieChart>
                  </Col>
                </Row>
                <Row className="px-2 mt-2">
                  <Col>
                    <Button style={{
                      width: '8rem',
                      color: 'white',
                      backgroundColor: 'slategray',
                      borderRadius: '5px'
                    }}>
                      View More
                    </Button>
                  </Col>
                  <Col>
                    <Button variant="contained" color="success" style={{
                      color: 'white',
                      backgroundColor: 'slategray',
                      borderRadius: '5px'
                    }}>
                      <FontAwesomeIcon icon={faPlus} className='ml-1 mr-1' />
                      Create
                    </Button>
                  </Col>
                </Row>
              </Card>
            </Col>
            <Col className="ml-auto mr-auto" md="10" xl="4">
              <Card>
                <Row>
                  <Col className="ml-auto mr-auto" >
                    <PieChart id="pie"
                      palette="soft pastel"
                      title="Blogs"
                      dataSource={[{
                        country: 'Technical',
                        area: 28
                      }, {
                        country: 'Non-Technical',
                        area: 3
                      }, {
                        country: 'General',
                        area: 7
                      }, {
                        country: 'Others',
                        area: 56
                      }]}
                    >
                      <Legend
                        orientation="horizontal"
                        itemTextPosition="right"
                        horizontalAlignment="center"
                        verticalAlignment="bottom"
                      />
                      <Series argumentField="country" valueField="area">
                        <Label
                          visible={true}>
                          <Font size={13} />
                          <Connector visible={true} width={0.5} />
                        </Label>
                      </Series>
                    </PieChart>
                  </Col>
                </Row>
                <Row className="px-2 mt-2">
                  <Col>
                    <Button style={{
                      width: '8rem',
                      color: 'white',
                      backgroundColor: 'slategray',
                      borderRadius: '5px'
                    }}>
                      View More
                    </Button>
                  </Col>
                  <Col>
                    <Button variant="contained" color="success" style={{
                      color: 'white',
                      backgroundColor: 'slategray',
                      borderRadius: '5px'
                    }}>
                      <FontAwesomeIcon icon={faPlus} className='ml-1 mr-1' />
                      Create
                    </Button>
                  </Col>
                </Row>
              </Card>
            </Col>
          </Row>
        </section>
        <section className="container-fluid pt-0">
          <Row>
            <div className="col-4">
              <Card>
                <div className="pl-3 pt-3">
                  <h5>Latest Artifacts</h5>
                </div>
                <hr className="mt-1 mb-2" style={{ boxShadow: '0px 3px 0px 2px slategray' }}></hr>
                <Timeline >
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot />
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Row>
                        <Col className="col-1">
                          <DescriptionIcon />
                        </Col>
                        <Col>
                          <h5 style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }}><Link>Fundamentals In React</Link></h5>
                          <Typography variant="body2" style={{
                            margin: '0px',
                            textAlign: 'initial',
                            fontSize: '11px',
                            padding: '4px 0px'
                          }} color="textSecondary" component="p">Create By Manidhar, published on 24/06/2020<br></br><Rating name="read-only" value={4} size='small' readOnly /></Typography>
                        </Col>
                      </Row>
                    </TimelineContent>
                  </TimelineItem>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot />
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Row>
                        <Col className="col-1">
                          <DescriptionIcon />
                        </Col>
                        <Col>
                          <h5 style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }}><Link>Core Java</Link></h5>
                          <Typography variant="body2" style={{
                            margin: '0px',
                            textAlign: 'initial',
                            fontSize: '11px',
                            padding: '4px 0px'
                          }} color="textSecondary" component="p">Create By Sunil, published on 24/06/2020<br></br><Rating name="read-only" value={3} size='small' readOnly /></Typography>
                        </Col>
                      </Row>
                    </TimelineContent>
                  </TimelineItem>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot />
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Row>
                        <Col className="col-1">
                          <DescriptionIcon />
                        </Col>
                        <Col>
                          <h5 style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }}><Link>Full stack Development(MERN)</Link></h5>
                          <Typography variant="body2" style={{
                            margin: '0px',
                            textAlign: 'initial',
                            fontSize: '11px',
                            padding: '4px 0px'
                          }} color="textSecondary" component="p">Create By Siddartha, published on 24/06/2020<br></br><Rating name="read-only" value={5} size='small' readOnly /></Typography>
                        </Col>
                      </Row>
                    </TimelineContent>
                  </TimelineItem>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot />
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Row>
                        <Col className="col-1">
                          <DescriptionIcon />
                        </Col>
                        <Col>
                          <h5 style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }}><Link>Web Apps using .NET</Link></h5>
                          <Typography variant="body2" style={{
                            margin: '0px',
                            textAlign: 'initial',
                            fontSize: '11px',
                            padding: '4px 0px'
                          }} color="textSecondary" component="p">Create By Abhipsa, published on 24/06/2020<br></br><Rating name="read-only" value={4} size='small' readOnly /></Typography>
                        </Col>
                      </Row>
                    </TimelineContent>
                  </TimelineItem>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Row>
                        <Col className="col-1">
                          <DescriptionIcon />
                        </Col>
                        <Col>
                          <h5 style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }}><Link>Fundamentals In JavaScript</Link></h5>
                          <Typography variant="body2" style={{
                            margin: '0px',
                            textAlign: 'initial',
                            fontSize: '11px',
                            padding: '4px 0px'
                          }} color="textSecondary" component="p">Create By Manidhar, published on 24/06/2020<br></br><Rating name="read-only" value={3} size='small' readOnly /></Typography>
                        </Col>
                      </Row>
                    </TimelineContent>
                  </TimelineItem>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Row>
                        <Col className="col-1">
                          <DescriptionIcon />
                        </Col>
                        <Col>
                          <h5 style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }}><Link>Basics of React JS</Link></h5>
                          <Typography variant="body2" style={{
                            margin: '0px',
                            textAlign: 'initial',
                            fontSize: '11px',
                            padding: '4px 0px'
                          }} color="textSecondary" component="p">Create By Priti, published on 24/06/2020<br></br><Rating name="read-only" value={3} size='small' readOnly /></Typography>
                        </Col>
                      </Row>
                    </TimelineContent>
                  </TimelineItem>
                </Timeline>
              </Card>
            </div>
            <div className="col">
              <Row className="mb-2 mr-1" style={{
                borderRadius: '9px'
              }}>
                <Card>
                <div >
                  <h5>Ongoing Events</h5>
                </div>
                <hr className="mt-1 mb-2" style={{ boxShadow: '0px 3px 0px 2px slategray' }}></hr>
                <Carousel style={{width: '-webkit-fill-available'}}>
                  <Row>

                    <Col><h2 >{items[1].name}</h2>
                      <p >{items[1].description}</p>

                      <Button variant="contained" color="success" style={{
                        color: 'white',
                        backgroundColor: 'slategray',
                        borderRadius: '5px'
                      }}>
                        Check it out!
            </Button>
                    </Col>
                    <Col><div
                      style={{
                        width: '100%',
                        height: '100%',
                        backgroundSize: 'cover',
                        backgroundImage: "url(" + require('./hackathon.png') + ")",
                      }}
                    >

                    </div></Col>
                  </Row>


                  <Row>
                    <Col><div
                      style={{
                        width: '100%',
                        height: '100%',
                        backgroundSize: 'cover',
                        backgroundImage: "url(" + require('./React.png') + ")",
                      }}
                    >
                    </div></Col><Col><div>
                      <h2>{items[2].name}</h2>
                      <p>{items[2].description}</p>

                      <Button variant="contained" color="success" style={{
                        color: 'white',
                        backgroundColor: 'slategray',
                        borderRadius: '5px'
                      }}>
                        Check it out!
            </Button>

                    </div></Col>
                  </Row>
                </Carousel>
              </Card>
              </Row>
              <Row>
                <Col className="pl-0">
                  <Card>
                  <div className="p-3">
                    <h5>Top Bloggers</h5>
                  </div>
                  {/* <Card className="m-1" style={{
                    width: '91%'
                  }}>
                    <CardContent>
                      <Row>
                        <Col className="col-1">
                          <AccountCircleIcon />
                        </Col>
                        <Col>
                          <h5 style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }}><Link>Priti</Link></h5>
                          <Typography variant="body2" style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }} color="textSecondary" component="p">Blogs:8 Replies:40</Typography>
                        </Col>
                      </Row>
                    </CardContent>
                  </Card> */}
                  <Card className="m-1" style={{
                    width: '91%'
                  }}>
                    <CardContent>
                      <Row>
                        <Col className="col-1">
                          <AccountCircleIcon />
                        </Col>
                        <Col>
                          <h5 style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }}><Link>John</Link></h5>
                          <Typography variant="body2" style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }} color="textSecondary" component="p">Blogs:8 Replies:30</Typography>
                        </Col>
                      </Row>
                    </CardContent>
                  </Card>
                  <Card className="m-1" style={{
                    width: '91%'
                  }}>
                    <CardContent>
                      <Row>
                        <Col className="col-1">
                          <AccountCircleIcon />
                        </Col>
                        <Col>
                          <h5 style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }}><Link>Mary</Link></h5>
                          <Typography variant="body2" style={{
                            margin: '0px',
                            textAlign: 'initial'
                          }} color="textSecondary" component="p">Blogs:7 Replies:20</Typography>
                        </Col>
                      </Row>
                    </CardContent>
                  </Card>
                  </Card>
                </Col>
                <div className="card mb-2" style={{
                  width: '50%',
                  height: '100%',
                  paddingRight: '15px',
                  paddingLeft: '15px',
                  marginRight: '22px'
                }}>
                  <div className="pl-3 pt-3">
                    <h5 style={{ textAlign: 'initial' }}>Frequent Searches</h5>
                  </div>
                  <hr className="mt-1 mb-2" style={{ boxShadow: '0px 3px 0px 2px slategray' }}></hr>
                  <ul className="lists_cards">
                    <li><Link>What is the Onboarding Process?</Link></li>
                    <li><Link>React Fundamentals</Link></li>
                    <li><Link>Project Documents</Link></li>
                    <li><Link>Discussion Forums</Link></li>
                    <li><Link>Machine Learning</Link></li>
                    <li><Link>Artificial Intelligence</Link></li>
                    <li><Link>Build a Chatbot</Link></li>
                    <li><Link>Responsive Web Design</Link></li>
                    <li><Link>Fuzzy search logic</Link></li>
                  </ul>
                </div>
              </Row>
            </div>
          </Row>
        </section>
      </div>
    </>
  );
}
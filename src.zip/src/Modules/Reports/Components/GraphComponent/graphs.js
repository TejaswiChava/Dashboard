import React from 'react';
import { Bar, Pie } from "react-chartjs-2";
import Table from '../../../../SharedModules/Table/Components/Table';
import GraphCSS from './graphs.module.css';
import ToggleButtons from '../ToggleButton/ToggleButton';
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import { makeStyles } from '@material-ui/core/styles';
import Select from "@material-ui/core/Select";
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import FilterListIcon from "@material-ui/icons/FilterList";
import Checkbox from "@material-ui/core/Checkbox";
import Input from "@material-ui/core/Input";
import ListItemText from "@material-ui/core/ListItemText";
import ClearAllIcon from '@material-ui/icons/ClearAll';
import Save from '@material-ui/icons/SaveRounded';

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));
let pieOriginaldata = {
  labels: [
    'GHS-TouchDown',
    'GHS-NonTouchDown',
    'NonGHS-TouchDown',
    'NONGHS-NonTouchDown'
  ],
  datasets: [{
    data: [30, 50, 70, 20],
    backgroundColor: [
    '#FF6384',
    '#36A2EB',
    '#FFCE56',
    '#2DCE89'
    ],
    hoverBackgroundColor: [
    '#FF6384',
    '#36A2EB',
    '#FFCE56',
    '#2DCE89'
    ]
  }]
};

export default function Graphs(props) {
    const[showGrid, setShowGrid] = React.useState(true);
    const classes = useStyles();
const optionsChart = {
    // maintainAspectRatio: false,
    // cornerRadius: 8,
    legend: {
      display: true,
      position: "top",
      labels: {
        fontColor: "#8898AA"
      }
    },
    scales: {
      yAxes: [
        {
          gridLines: {
            color: "#DEE2E6",
            zeroLineColor: "#DEE2E6"
          },
          ticks: {
            fontColor: "black",
            callback: function(value) {
              if (!(value % 2)) {
                //return '$' + value + 'k'
                return value;
              }
            }
          },
          stacked: true
        }
      ],
      xAxes: [
        {
          ticks: {
            fontColor: "black"
          },
          stacked: true
        }
      ]
    },
    // tooltips: { // Khi rê chuột hiển thị từng data
    //   callbacks: {
    //     label: function(item, data) {
    //       var label = data.datasets[item.datasetIndex].label || "";
    //       var yLabel = item.yLabel;
    //       var content = "";
    //       if (data.datasets.length > 1) {
    //         content += label;
    //       }
    //       content += yLabel;
    //       return content;
    //     }
    //   }
    // }
  
    //Khi rê chuột hiển thị tất cả data
    tooltips: {
      enabled: true,
      mode: "index",
      intersect: true
    }
  };
  
const MenuProps = {
  getContentAnchorEl: null,
  anchorOrigin: {
    // vertical: "top",
    // horizontal: "left"
    vertical: "bottom",
    horizontal: "left"
  }
};
const [criteria, setCriteria] = React.useState({
  status: 1,
  assets: 1,
  cluster: 1,
  project: 1,
  pieChange: 3
});
const [barChartXAsis, setBarChartXAsis] = React.useState([
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
]);
const [filterBarChartXAsis, setFilterBarChartXAsis] = React.useState([
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
]);

const data = {
  labels: filterBarChartXAsis,
  datasets: [
    {
      label: "All",
      data: [30, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29],
      backgroundColor: "#716ACA",
      fontColor: "white"
    },
    {
      label: "Active Employee",
      backgroundColor: "#11CDEF",
      fontColor: "#11CDEF",
      data: [12, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29]
    },
    {
      label: "De-boarded Employee",
      data: [20, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29],
      backgroundColor: "#FFB822",
      fontColor: "white"
    },
    {
      label: "Resigned ",
      backgroundColor: "#F4516C",
      fontColor: "#11CDEF",
      data: [52, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29]
    },
    {
      label: "TBD",
      data: [25, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29],
      backgroundColor: "#2DCE89",
      fontColor: "white"
    }
  ]
};
const columns = [

  { id: 'employeeId', label: 'CID'},
  { id: 'name', label: 'Employee Name' },
  { id: 'cluster', label: 'Cluster'},
  { id: 'Status', label: 'Status' },
];
const tabledata = [
  {employeeId:'C5075201', name:'Sidharth', cluster:'FSS', Status:'Active'},
  {employeeId:'C5075202', name:'Manidhar', cluster:'FSS', Status:'Active'},
  {employeeId:'C5075203', name:'Rashmita',cluster:'SMART', Status:'Active'},
  {employeeId:'C5075204', name:'Keerthi', cluster:'RxD', Status:'Active'}
];
const [barChartFilterOpen, setBarChartFilterOpen] = React.useState(false);
const [clearBarChartLegends, setClearBarChartLegends] = React.useState(false);
const [clearPieChartLegends, setCleaPieChartLegends] = React.useState(false);
const [pieData, setPieData] = React.useState(pieOriginaldata);
const [showTable, setShowTable] = React.useState(false);
const [values, setValues] = React.useState({
  employeeStatus: 'active'
})
const handleChange = name => event => {
  setCriteria({ ...criteria, [name]: event.target.value });
  if (name === 'pieChange') {
    let data = pieOriginaldata;
    if (event.target.value === 3) {
      console.log("first 3");
      data.datasets[0].data = [30, 50, 90];
    }
    if (event.target.value === 6) {
      data.datasets[0].data = [100, 60, 180];
        }
        if (event.target.value === 9) {
          data.datasets[0].data = [150, 270, 90];
            }
    setPieData(data);
    setCleaPieChartLegends(false);
  }
};
const showTableClk = event => {
  setShowTable(!showTable);
}
const barCharthandleChange = event => {
  console.log(event.target.value);
  setFilterBarChartXAsis(event.target.value );
}

const filterHandleClose = event => {
  console.log('close');
  setBarChartFilterOpen(false);
};

const filterHandleOpen = event => {
  console.log('open');
  setBarChartFilterOpen(true);
  setClearBarChartLegends(false);
};
const clearBarChartFilter = event => {
  setFilterBarChartXAsis(barChartXAsis);
  setClearBarChartLegends(true);
}
const onBarChartClick = event => {
  setClearBarChartLegends(false);
};
const clearPieChartFilter = event => {
  setCleaPieChartLegends(true);
  setCriteria({ ...criteria, 'pieChange': 3 });
}
const onPieChartClick = event => {
  setCleaPieChartLegends(false);
};
    return(
        <div>
              <div className={GraphCSS.toggleRight}>
            <ToggleButtons showGrid={showGrid} setShowGrid={setShowGrid}/>
            </div>
            {showGrid ? <div>
              <div className={GraphCSS.formwrapper}>
         <div className="mui-custom-form ml-0">
                    <TextField
                    id="typeof-contract"
                    fullWidth
                    label="Employee Status"
                    type="string"
                    select
                    inputProps={{ maxLength: 15 }}
                    value={values.employeeStatus}
                    // onChange={}
                    InputLabelProps={{
                        shrink: true
                    }}
                    >
                        <MenuItem
                            selected
                            key="Please Select One"
                            value="Please Select One"
                        >
                            All
                        </MenuItem>
                        <MenuItem
                            selected
                            key="active"
                            value="active"
                        >
                            Active
                        </MenuItem>
                    </TextField>
                </div>
                <div className="mui-custom-form">
                    <TextField
                    id="typeof-contract"
                    fullWidth
                    label="Contract Type"
                    type="string"
                    select
                    inputProps={{ maxLength: 15 }}
                    // value={}
                    // onChange={}
                    InputLabelProps={{
                        shrink: true
                    }}
                    >
                        <MenuItem
                            selected
                            key="Please Select One"
                            value="Please Select One"
                        >
                            All
                        </MenuItem>
                        <MenuItem
                            selected
                            key="Please Select One"
                            value="Please Select One"
                        >
                            Active
                        </MenuItem>
                    </TextField>
                </div>
                <div className="mui-custom-form">
                    <TextField
                    id="typeof-contract"
                    fullWidth
                    label="Cluster Name"
                    type="string"
                    select
                    inputProps={{ maxLength: 15 }}
                    // value={}
                    // onChange={}
                    InputLabelProps={{
                        shrink: true
                    }}
                    >
                        <MenuItem
                            selected
                            key="Please Select One"
                            value="Please Select One"
                        >
                            All
                        </MenuItem>
                        <MenuItem
                            selected
                            key="Please Select One"
                            value="Please Select One"
                        >
                            Active
                        </MenuItem>
                    </TextField>
                </div>
                <div className={GraphCSS.generate}>
              
           {/*    <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className="submit"
            //onClick={showTableClk}
          >
            Generate Report
          </Button> */}
          <Button  className="btn-addEmployee" variant="contained" color="primary" 
         //onClick={showTableClk}
          >
        Generate Report
      </Button>
      </div>
      {/* <div><Save></Save></div> */}
      
              </div>
           
              <div className={GraphCSS.TableImg}>
                 <Table headCells={columns} tableData={tabledata}/>
                 </div>
               {showTable ? <div className={GraphCSS.TableImg}>
                 <Table headCells={columns} tableData={tabledata}/>
         {/*  <img src={TableImg} alt="Logo" style={{height: '385px'}} /> */}
        </div> : null} 
            </div>
             : <div className={GraphCSS.flexIitems}>
             <div className={GraphCSS.flexIitem}>
               <h3>Employee-Status Report</h3>
             <Bar
             data={data}
             options={optionsChart}
             redraw={clearBarChartLegends}
             onElementsClick={onBarChartClick}
             />
             <div>
              <FormControl>
                <div>
                <Button id="openMenu" onClick={filterHandleOpen} variant="raised">
                  <FilterListIcon />
                </Button>
                <Button id="clearBarChart" onClick={clearBarChartFilter} variant="raised">
                  <ClearAllIcon />
                </Button>
                </div>
              </FormControl>
        <FormControl>
        <Select
          labelId="demo-mutiple-checkbox-label"
          id="demo-mutiple-checkbox"
          multiple
          open={barChartFilterOpen}
          onClose={filterHandleClose}
          value={filterBarChartXAsis}
          onChange={barCharthandleChange}
          input={<Input />}
          style={{ display: "none" }}
          MenuProps={{
            anchorEl: document.getElementById("openMenu"),
            style: { marginTop: 30 }
          }}
        >
          {barChartXAsis.map((name) => (
            <MenuItem key={name} value={name}>
              <Checkbox checked={filterBarChartXAsis.indexOf(name) > -1} />
              <ListItemText primary={name} />
            </MenuItem>
          ))}
        </Select>
      </FormControl>
             </div>
             </div>
             <div className={GraphCSS.flexIitem}>
             <h3>Employee-Contract Report</h3>
             <Pie
             data={pieData}
             redraw={clearPieChartLegends}
             onElementsClick={onPieChartClick}
             />
             <br></br>
             <div>
              <FormControl>
          {/* <InputLabel htmlFor="age-simple">pieChange</InputLabel> */}
          <Select
            value={criteria.pieChange}
            onChange={handleChange("pieChange")}
            inputProps={{
              name: "age",
              id: "age-simple"
            }}
            MenuProps={MenuProps}
          >
            <MenuItem value={3}>Last 3 months</MenuItem>
            <MenuItem value={6}>Last 6 months</MenuItem>
            <MenuItem value={9}>Last 9 months</MenuItem>
          </Select>
        </FormControl>
        <Button id="clearPieChart" onClick={clearPieChartFilter} variant="raised">
                  <ClearAllIcon />
                </Button>
              </div>
             </div>
         </div>}
        
        </div>
    );
}
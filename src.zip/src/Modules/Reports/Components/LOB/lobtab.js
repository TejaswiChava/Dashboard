import React from 'react';
import { Bar, Pie } from "react-chartjs-2";
import { makeStyles } from '@material-ui/core/styles';
import GraphCSS from './lobtab.module.css';
import Table from '../../../../SharedModules/Table/Components/Table';
import ToggleButtons from '../../../../Modules/Reports/Components/ToggleButton/ToggleButton';
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import Button from '@material-ui/core/Button';
import FilterListIcon from "@material-ui/icons/FilterList";
import Checkbox from "@material-ui/core/Checkbox";
import Input from "@material-ui/core/Input";
import ListItemText from "@material-ui/core/ListItemText";
import ClearAllIcon from '@material-ui/icons/ClearAll';

let pieOriginaldata = {
  labels: [
    'GHS-TouchDown',
    'GHS-NonTouchDown',
    'NonGHS-TouchDown',
    'NONGHS-NonTouchDown'
  ],
  datasets: [{
    data: [30, 50, 70, 20],
    backgroundColor: [
    '#FF6384',
    '#36A2EB',
    '#FFCE56',
    '#2DCE89'
    ],
    hoverBackgroundColor: [
    '#FF6384',
    '#36A2EB',
    '#FFCE56',
    '#2DCE89'
    ]
  }]
};

export default function Graphs(props) {
    const[showGrid, setShowGrid] = React.useState(true);
const optionsChart = {
    // maintainAspectRatio: false,
    // cornerRadius: 8,
    legend: {
      display: true,
      position: "top",
      labels: {
        fontColor: "#8898AA"
      }
    },
    scales: {
      yAxes: [
        {
          gridLines: {
            color: "#DEE2E6",
            zeroLineColor: "#DEE2E6"
          },
          ticks: {
            fontColor: "black",
            callback: function(value) {
              if (!(value % 2)) {
                //return '$' + value + 'k'
                return value;
              }
            }
          },
          stacked: true
        }
      ],
      xAxes: [
        {
          ticks: {
            fontColor: "black"
          },
          stacked: true
        }
      ]
    },
    // tooltips: { // Khi rê chuột hiển thị từng data
    //   callbacks: {
    //     label: function(item, data) {
    //       var label = data.datasets[item.datasetIndex].label || "";
    //       var yLabel = item.yLabel;
    //       var content = "";
    //       if (data.datasets.length > 1) {
    //         content += label;
    //       }
    //       content += yLabel;
    //       return content;
    //     }
    //   }
    // }
  
    //Khi rê chuột hiển thị tất cả data
    tooltips: {
      enabled: true,
      mode: "index",
      intersect: true
    }
  };
  
const MenuProps = {
  getContentAnchorEl: null,
  anchorOrigin: {
    // vertical: "top",
    // horizontal: "left"
    vertical: "bottom",
    horizontal: "left"
  }
};
const [criteria, setCriteria] = React.useState({
  status: 1,
  assets: 1,
  cluster: 1,
  project: 1,
  pieChange: 3
});
const [barChartXAsis, setBarChartXAsis] = React.useState([
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
]);
const [filterBarChartXAsis, setFilterBarChartXAsis] = React.useState([
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
]);

const data = {
  labels: filterBarChartXAsis,
  datasets: [
    {
      label: "All",
      data: [30, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29],
      backgroundColor: "#716ACA",
      fontColor: "white"
    },
    {
      label: "Ongoing Tasks",
      backgroundColor: "#11CDEF",
      fontColor: "#11CDEF",
      data: [12, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29]
    },
    {
      label: "Closed",
      data: [20, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29],
      backgroundColor: "#FFB822",
      fontColor: "white"
    },
    {
      label: "Proposed ",
      backgroundColor: "#F4516C",
      fontColor: "#11CDEF",
      data: [52, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29]
    },
    {
      label: "Defects Logged",
      data: [25, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29],
      backgroundColor: "#2DCE89",
      fontColor: "white"
    }
  ]
};
const columns = [
  { id: 'employeeId', label: 'DefectId'},
  { id: 'name', label: 'Employee Name' },
  { id: 'cluster', label: 'Cluster'},
  { id: 'status', label: 'Status' },
];
const tabledata = [
  {employeeId:'Keerthi', name:'RxD', cluster:'In-Active',Status:'In-Active'},
  {employeeId:'Sidharth', name:'FSS', cluster:'Active', Status:'Active'},
  {employeeId:'Rashmita', name:'SMART',cluster:'In-Active',Status:'In-Active'},
  {employeeId:'Manidhar', name:'FSS', cluster:'Active',Status:'Active'}
];
const [barChartFilterOpen, setBarChartFilterOpen] = React.useState(false);
const [clearBarChartLegends, setClearBarChartLegends] = React.useState(false);
const [clearPieChartLegends, setCleaPieChartLegends] = React.useState(false);
const [pieData, setPieData] = React.useState(pieOriginaldata);
const [showTable, setShowTable] = React.useState(false);
const handleChange = name => event => {
  setCriteria({ ...criteria, [name]: event.target.value });
  if (name === 'pieChange') {
    let data = pieOriginaldata;
    if (event.target.value === 3) {
      console.log("first 3");
      data.datasets[0].data = [30, 50, 90];
    }
    if (event.target.value === 6) {
      data.datasets[0].data = [100, 60, 180];
        }
        if (event.target.value === 9) {
          data.datasets[0].data = [150, 270, 90];
            }
    setPieData(data);
    setCleaPieChartLegends(false);
  }
};
const showTableClk = event => {
  setShowTable(!showTable);
}
const barCharthandleChange = event => {
  console.log(event.target.value);
  setFilterBarChartXAsis(event.target.value );
}

const filterHandleClose = event => {
  console.log('close');
  setBarChartFilterOpen(false);
};

const filterHandleOpen = event => {
  console.log('open');
  setBarChartFilterOpen(true);
  setClearBarChartLegends(false);
};
const clearBarChartFilter = event => {
  setFilterBarChartXAsis(barChartXAsis);
  setClearBarChartLegends(true);
}
const onBarChartClick = event => {
  setClearBarChartLegends(false);
};
const clearPieChartFilter = event => {
  setCleaPieChartLegends(true);
  setCriteria({ ...criteria, 'pieChange': 3 });
}
const onPieChartClick = event => {
  setCleaPieChartLegends(false);
};
    return(
        <div>
            <div className={GraphCSS.toggleRight}>
            <ToggleButtons showGrid={showGrid} setShowGrid={setShowGrid}/>
            </div>
            {showGrid ? <div>
              <div className={GraphCSS.flexIitems}>
              <div className={GraphCSS.flexIitem}>
              <FormControl>
          <InputLabel htmlFor="age-simple">Defects Status</InputLabel>
          <Select
            value={criteria.status}
            onChange={handleChange("status")}
            inputProps={{
              name: "age",
              id: "age-simple"
            }}
            MenuProps={MenuProps}
          >
            <MenuItem value={1}>
              <em>Please Select</em>
            </MenuItem>
            <MenuItem value={10}>All</MenuItem>
            <MenuItem value={20}>Ongoing</MenuItem>
            <MenuItem value={30}>Closed</MenuItem>
            <MenuItem value={40}>Proposed</MenuItem>
            <MenuItem value={50}>Defects Logged</MenuItem>
          </Select>
        </FormControl>
              </div>
              {/* <div className={GraphCSS.flexIitem}>
              <FormControl>
          <InputLabel htmlFor="age-simple">Employee Assets</InputLabel>
          <Select
            value={criteria.assets}
            onChange={handleChange("assets")}
            inputProps={{
              name: "age",
              id: "age-simple"
            }}
            MenuProps={MenuProps}
          >
            <MenuItem value={1}>
              <em>Please Select</em>
            </MenuItem>
            <MenuItem value={10}>Laptop</MenuItem>
            <MenuItem value={20}>KeyBoard</MenuItem>
            <MenuItem value={30}>Lan Wire</MenuItem>
          </Select>
        </FormControl>
              </div> */}
              <div className={GraphCSS.flexIitem}>
              <FormControl>
          <InputLabel htmlFor="age-simple">Cluster Name</InputLabel>
          <Select
            value={criteria.cluster}
            onChange={handleChange("cluster")}
            inputProps={{
              name: "age",
              id: "age-simple"
            }}
            MenuProps={MenuProps}
          >
            <MenuItem value={1}>
              <em>Please Select</em>
            </MenuItem>
            <MenuItem value={10}>FSS</MenuItem>
            <MenuItem value={20}>AK EOMB</MenuItem>
            <MenuItem value={30}>FRR</MenuItem>
            <MenuItem value={40}>SLR</MenuItem>
            <MenuItem value={50}>FSS Extension</MenuItem>
            <MenuItem value={60}>EDI</MenuItem>
            <MenuItem value={70}>CWP</MenuItem>
          </Select>
        </FormControl>
              </div>
        {/*       <div className={GraphCSS.flexIitem}>
              <FormControl >
          <InputLabel htmlFor="age-simple">Cluster Name</InputLabel>
          <Select
            value={criteria.project}
            onChange={handleChange("project")}
            inputProps={{
              name: "age",
              id: "age-simple"
            }}
            MenuProps={MenuProps}
          >
            <MenuItem value={1}>
              <em>Please Select</em>
            </MenuItem>
            <MenuItem value={10}>FSS</MenuItem>
            <MenuItem value={20}>AK EOMB</MenuItem>
            <MenuItem value={30}>FRR</MenuItem>
            <MenuItem value={40}>SLR</MenuItem>
            <MenuItem value={50}>FSS Extension</MenuItem>
            <MenuItem value={60}>EDI</MenuItem>
            <MenuItem value={70}>CWP</MenuItem>
             <MenuItem value={80}>TBD</MenuItem>
          
          </Select>
        </FormControl>
              </div> */}
              <div className={GraphCSS.flexIitem}>
              <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className="submit"
            onClick={showTableClk}
          >
            Generate Report
          </Button>
              </div>
              </div>
              {showTable ? <div className={GraphCSS.TableImg}>
                 <Table headCells={columns} tableData={tabledata}/>
         {/* <img src={TableImg} alt="Logo" style={{height: '385px'}} /> */}
        </div> : null} 
            </div>
             : <div className={GraphCSS.flexIitems}>
             <div className={GraphCSS.flexIitem}>
               <h3>Defects-Status Report</h3>
             <Bar
             data={data}
             options={optionsChart}
             redraw={clearBarChartLegends}
             onElementsClick={onBarChartClick}
             />
             <div>
              <FormControl>
                <div>
                <Button id="openMenu" onClick={filterHandleOpen} variant="raised">
                  <FilterListIcon />
                </Button>
                <Button id="clearBarChart" onClick={clearBarChartFilter} variant="raised">
                  <ClearAllIcon />
                </Button>
                </div>
              </FormControl>
        <FormControl>
        <Select
          labelId="demo-mutiple-checkbox-label"
          id="demo-mutiple-checkbox"
          multiple
          open={barChartFilterOpen}
          onClose={filterHandleClose}
          value={filterBarChartXAsis}
          onChange={barCharthandleChange}
          input={<Input />}
          style={{ display: "none" }}
          MenuProps={{
            anchorEl: document.getElementById("openMenu"),
            style: { marginTop: 30 }
          }}
        >
          {barChartXAsis.map((name) => (
            <MenuItem key={name} value={name}>
              <Checkbox checked={filterBarChartXAsis.indexOf(name) > -1} />
              <ListItemText primary={name} />
            </MenuItem>
          ))}
        </Select>
      </FormControl>
             </div>
             </div>
             <div className={GraphCSS.flexIitem}>
             <h3>Cluster Report</h3>
             <Pie
             data={pieData}
             redraw={clearPieChartLegends}
             onElementsClick={onPieChartClick}
             />
             <br></br>
             <div>
              <FormControl>
          {/* <InputLabel htmlFor="age-simple">pieChange</InputLabel> */}
          <Select
            value={criteria.pieChange}
            onChange={handleChange("pieChange")}
            inputProps={{
              name: "age",
              id: "age-simple"
            }}
            MenuProps={MenuProps}
          >
            <MenuItem value={3}>Last 3 months</MenuItem>
            <MenuItem value={6}>Last 6 months</MenuItem>
            <MenuItem value={9}>Last 9 months</MenuItem>
          </Select>
        </FormControl>
        <Button id="clearPieChart" onClick={clearPieChartFilter} variant="raised">
                  <ClearAllIcon />
                </Button>
              </div>
             </div>
         </div>}
        
        </div>
    );
}
import React from 'react';
import { Bar, Pie } from "react-chartjs-2";
import GraphCSS from './operations.module.css';
import ToggleButtons from '../ToggleButton/ToggleButton';
import InputLabel from "@material-ui/core/InputLabel";
import { makeStyles } from '@material-ui/core/styles';
import FormHelperText from '@material-ui/core/FormHelperText';
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import NativeSelect from "@material-ui/core/NativeSelect";
import Button from '@material-ui/core/Button';

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));
export default function Graphs(props) {
  const classes = useStyles();
  const [state, setState] = React.useState({
    age: '',
    name: 'hai',
  });
    const[showGrid, setShowGrid] = React.useState(true);
const optionsChart = {
    legend: {
      display: true,
      position: "top",
      labels: {
        fontColor: "#8898AA"
      }
    },
    scales: {
      yAxes: [
        {
          gridLines: {
            color: "#DEE2E6",
            zeroLineColor: "#DEE2E6"
          },
          ticks: {
            fontColor: "black",
            callback: function(value) {
              if (!(value % 2)) {
                //return '$' + value + 'k'
                return value;
              }
            }
          },
          stacked: true
        }
      ],
      xAxes: [
        {
          ticks: {
            fontColor: "black"
          },
          stacked: true
        }
      ]
    },
    // tooltips: { // Khi rê chuột hiển thị từng data
    //   callbacks: {
    //     label: function(item, data) {
    //       var label = data.datasets[item.datasetIndex].label || "";
    //       var yLabel = item.yLabel;
    //       var content = "";
    //       if (data.datasets.length > 1) {
    //         content += label;
    //       }
    //       content += yLabel;
    //       return content;
    //     }
    //   }
    // }
  
    //Khi rê chuột hiển thị tất cả data
    tooltips: {
      enabled: true,
      mode: "index",
      intersect: true
    }
  };
  
  const data = {
    labels: [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ],
    datasets: [
      {
        label: "Working Employee ",
        data: [30, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29],
        backgroundColor: "#716ACA",
        fontColor: "white"
      },
      {
        label: "New Employee ",
        backgroundColor: "#11CDEF",
        fontColor: "#11CDEF",
        data: [12, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29]
      },
      {
        label: "Allowed Leave ",
        data: [20, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29],
        backgroundColor: "#FFB822",
        fontColor: "white"
      },
      {
        label: "Resigned ",
        backgroundColor: "#F4516C",
        fontColor: "#11CDEF",
        data: [52, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29]
      },
      {
        label: "Marternity ",
        data: [25, 20, 30, 22, 17, 29, 25, 20, 30, 22, 17, 29],
        backgroundColor: "#2DCE89",
        fontColor: "white"
      }
    ]
  };
  const pieData = {
	labels: [
		'GHS-TouchDown',
		'GHS-NonTouchDown',
		'Non-GHS'
	],
	datasets: [{
		data: [300, 50, 100],
		backgroundColor: [
		'#FF6384',
		'#36A2EB',
		'#FFCE56'
		],
		hoverBackgroundColor: [
		'#FF6384',
		'#36A2EB',
		'#FFCE56'
		]
	}]
};
const MenuProps = {
  getContentAnchorEl: null,
  anchorOrigin: {
    // vertical: "top",
    // horizontal: "left"
    vertical: "bottom",
    horizontal: "left"
  }
};
const [criteria, setCriteria] = React.useState({
  status: 1,
  assets: 1,
  cluster: 1,
  project: 1
});
const [showTable, setShowTable] = React.useState(false);
const handleChange = name => event => {
  setCriteria({ ...criteria, [name]: event.target.value });
};
const showTableClk = event => {
  setShowTable(!showTable);
}
    return(
        <div>
            <div className={GraphCSS.toggleRight}>
            <ToggleButtons showGrid={showGrid} setShowGrid={setShowGrid}/>
            </div>
            {showGrid ? <div>
             
      <FormControl variant="outlined" className={classes.formControl}>
        <InputLabel htmlFor="outlined-age-native-simple">Age</InputLabel>
        <Select
          native
          value={state.age}
          onChange={handleChange}
          label="Age"
          inputProps={{
            name: 'age',
            id: 'outlined-age-native-simple',
          }}
        >
          <option aria-label="None" value="" />
          <option value={10}>Ten</option>
          <option value={20}>Twenty</option>
          <option value={30}>Thirty</option>
        </Select>
      </FormControl>
      
      <FormControl variant="outlined" className={classes.formControl}>
        <InputLabel htmlFor="outlined-age-native-simple">Age</InputLabel>
        <Select
          native
          value={state.age}
          onChange={handleChange}
          label="Age"
          inputProps={{
            name: 'age',
            id: 'outlined-age-native-simple',
          }}
        >
          <option aria-label="None" value="" />
          <option value={10}>Ten</option>
          <option value={20}>Twenty</option>
          <option value={30}>Thirty</option>
        </Select>
      </FormControl>
    
      
              
              <div className={classes.formControl}>
              <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className="submit"
            onClick={showTableClk}
          >
            Generate Report
          </Button>
              
              </div>
               {showTable ? <div className="TableImg">
          {/* <img src={TableImg} alt="Logo" style={{height: '385px'}} /> */}
        </div> : null} 
            </div>
             : <div className={GraphCSS.flexIitems}>
             <div className={GraphCSS.flexIitem}>
               <h3>Employee-Status Report</h3>
             <Bar data={data} options={optionsChart} />
             </div>
             <div className={GraphCSS.flexIitem}>
             <h3>Employee-Cluster Report</h3>
             <Pie data={pieData} />
             </div>
         </div>}
        
        </div>
    );
}
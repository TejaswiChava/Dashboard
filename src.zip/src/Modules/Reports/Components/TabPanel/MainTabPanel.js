import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Graphs from '../GraphComponent/graphs';
import Operations from '../OperationTab/operations';
import Lobtab from '../LOB/lobtab';
import PeopleIcon from '@material-ui/icons/People';
import LocalActivityIcon from '@material-ui/icons/LocalActivity';
import ViewColumnIcon from '@material-ui/icons/ViewColumn'; 
import TouchAppIcon from '@material-ui/icons/TouchApp';
import AvTimerIcon from '@material-ui/icons/AvTimer';
import AccessTimeIcon from '@material-ui/icons/AccessTime';
import TabPanel from './TabPanel';
import TabCSS from './TabPanel.scss';

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    'aria-controls': `scrollable-auto-tabpanel-${index}`,
  };
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    width: '100%',
    backgroundColor: theme.palette.background.paper,
  },
}));

export default function ScrollableTabsButtonAuto() {
  const classes = useStyles();
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <>
        <div className='container-fluid'>
            <div className='p-3'>
                <h2>Report Creation</h2>
            </div>
        </div>
    <div className={classes.root}>
      <AppBar position="static" color="default">
        <Tabs
          value={value}
          onChange={handleChange}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
          aria-label="scrollable auto tabs example"
          backgroundColor = "black"
        >
          <Tab label="Employee" icon={<PeopleIcon />} {...a11yProps(0)} style={{color:"teal"}} />
          <Tab label="LOB" icon={<ViewColumnIcon />} {...a11yProps(1)} style={{color:"teal"}}/>
          <Tab label="Operations" icon={<LocalActivityIcon />} {...a11yProps(2)} style={{color:"teal"}}/>
          <Tab label="Swipe" icon={<TouchAppIcon />} {...a11yProps(3)} style={{color:"teal"}} />
          <Tab label="SLA" icon={<AvTimerIcon />} {...a11yProps(4)} style={{color:"teal"}}/>
          <Tab label="TABS" icon={<AccessTimeIcon />} {...a11yProps(5)} style={{color:"teal"}}/>
        </Tabs>
      </AppBar>
      <TabPanel value={value} index={0}>
        <Graphs />
      </TabPanel>
      <TabPanel value={value} index={1}>
      <Lobtab/>
      </TabPanel>
      <TabPanel value={value} index={2}>
     <Operations/>
      </TabPanel>
      <TabPanel value={value} index={3}>
      Tab Four
      </TabPanel>
      <TabPanel value={value} index={4}>
      Tab Five
      </TabPanel>
      <TabPanel value={value} index={5}>
      Tab Six
      </TabPanel>
    </div>
  </>
  );
}
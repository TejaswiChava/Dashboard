import React from "react";
import ToggleButton from "@material-ui/lab/ToggleButton";
import ToggleButtonGroup from "@material-ui/lab/ToggleButtonGroup";
import GridOnIcon from "@material-ui/icons/GridOn";
import AssessmentIcon from "@material-ui/icons/Assessment";

export default function VerticalToggleButtons(props) {
    // showGrid={showGrid} setShowGrid={setShowGrid}
  const [view, setView] = React.useState("grid");

  const handleChange = (event, nextView) => {
    setView(nextView);
    props.setShowGrid(!props.showGrid);
  };

  return (
    <ToggleButtonGroup value={view} exclusive onChange={handleChange}>
      <ToggleButton value="grid" aria-label="Grid">
        <GridOnIcon />
      </ToggleButton>
      <ToggleButton value="report" aria-label="Reports">
        <AssessmentIcon />
      </ToggleButton>
    </ToggleButtonGroup>
  );
}

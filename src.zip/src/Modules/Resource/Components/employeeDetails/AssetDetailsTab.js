import React from "react";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Button from "@material-ui/core/Button";
import Radio from "@material-ui/core/Radio";
import Table from '../../../../SharedModules/Table/Components/Table';
import TextField from "@material-ui/core/TextField";

const headCells = [
    { id: "sNo", numeric: false, disablePadding: true, label: "S No" },
    { id: "softwareName", numeric: true, disablePadding: false, label: "Software Name" },
    { id: "accessStartDate", numeric: true, disablePadding: false, label: "Access Start Date" },
    { id: "accessEndDate", numeric: true, disablePadding: false, label: "Access End Date" },
  ];
  function createData(sNo, softwareName, accessStartDate, accessEndDate) {
    return { sNo, softwareName, accessStartDate, accessEndDate };
  }
  
  const rows = [
    createData("1", "VS code", '01/01/2020', '01/01/2020'),
    createData("2", "STS", '01/01/2020', '01/01/2020'),
    createData("3", "Maven", '01/01/2020', '01/01/2020'),
    createData("4", "Open JDK",'01/01/2020', '01/01/2020'),
  ];

function AssetDetails(props) {
  const { values, handleChange, showAssetError, showAssetDetailsErrorMsg } = props ;
  const [software, setSoftware] = React.useState(false);
  const [hardware, setHardware] = React.useState(true);
  const changeSoftware = () => {
    setSoftware(true);
    setHardware(false);
  };
  const chnageHardware = () => {
    setHardware(true);
    setSoftware(false);
  };
  return (
    <div>
      <Button
        variant="contained"
        color="primary"
        style={{ float: "right" }}
        onClick={chnageHardware}
      >
        Hardware
      </Button>
      <Button
        variant="contained"
        color="primary"
        style={{ float: "right" }}
        onClick={changeSoftware}
      >
        Software
      </Button>
      {hardware ? (
       
        <div className =  "asset-details">
             <div className="tab-heading float-left">
                {"Employee Asset Check list Hardware"}
            </div>
          <div className="form-wrapper">
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="secured"
                control={<Checkbox color="primary" 
                  checked={values.seccuredPassPhrase}
                  value = {values.seccuredPassPhrase} 
                  onChange = {handleChange('seccuredPassPhrase')}/>}
                label="Secured the Existing Employee's PGP Passphrase ?"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="lan"
                control={<Checkbox color="primary"
                 checked={values.lan} 
                 value = {values.lan}
                 onChange = {handleChange('lan')}/>}
                label="LAN and Facility access (with Cable)"
                labelPlacement="start"
              />
            </div>
          
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="pager"
                control={<Checkbox color="primary" 
                checked={values.manualDocuments} 
                value = {values.manualDocuments}
                onChange = {handleChange('manualDocuments')}
                />}
                label="Manual Documents"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="voice"
                control={<Checkbox color="primary" checked={values.voiceMail}
                value = {values.voiceMail}
                onChange = {handleChange('voiceMail')} />}
                label="Voice Mail"
                labelPlacement="start"
              />
            </div>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="secured"
                control={<Checkbox color="primary"
                 checked={values.companyCreditCard} 
                 value = {values.companyCreditCard}
                 onChange = {handleChange('companyCreditCard')}
                />}
                label="Company Credit card "
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="lan"
                control={<Checkbox color="primary" 
                checked={values.telephoneCard} 
                value = {values.telephoneCard}
                onChange = {handleChange('telephoneCard')}/>}
                label="Telephone Credit Card"
                labelPlacement="start"
              />
            </div>

            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="secured"
                control={<Checkbox color="primary" checked={values.airTravelCards} 
                value = {values.airTravelCards}
                onChange = {handleChange('airTravelCards')}/>}
                label="Air Travel cards "
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="lan"
                control={<Checkbox color="primary" checked={values.officekeys} 
                value = {values.officekeys}
                onChange = {handleChange('officekeys')}/>}
                label="Office/Desk keys"
                labelPlacement="start"
              />
            </div>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="pager"
                control={<Checkbox color="primary" checked={values.pager} 
                value = {values.pager}
                onChange = {handleChange('pager')}/>}
                label="Pager"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="voice"
                control={<Checkbox color="primary" 
                checked={values.employeeIdCard} 
                value = {values.employeeIdCard}
                onChange = {handleChange('employeeIdCard')}/>}
                label="Employee Id/ Security Card"
                labelPlacement="start"
              />
            </div>
            {values.employeeIdCard ?
            <TextField
              id="employee-hid-id"
              label="Employee HID Number"
              type="string"
              inputProps={{ maxLength: 15 }}
              InputLabelProps={{
                shrink: true,
              }}
              required = {values.employeeIdCard}
              value= {values.employeeHidNumber}
              onChange = {handleChange('employeeHidNumber')}
              style={{left: '64px'}}
            ></TextField>
           : null }
            
          </div>
          <div className="form-wrapper">
          <div className="mui-custom-form sub-radio float-left  margin-top-24">
          <FormControlLabel
                value="voice"
                control={<Checkbox color="primary" checked={values.headSet}
                value = {values.headSet}
                onChange = {handleChange('headSet')} />}
                label="Headset"
                labelPlacement="start"
              />
            </div>
            {values.headSet ?
            <TextField
              id="headset-serial-number"
              label="Headset Serial Number"
              type="string"
              inputProps={{ maxLength: 15 }}
              InputLabelProps={{
                shrink: true,
              }}
              required = {values.headSet}
              style={{left: '64px'}}
              value= {values.headsetSerialNumber}
              onChange = {handleChange('headsetSerialNumber')}
            ></TextField>
           : null }
            {values.headSet ?
            <TextField
              id="headset-make"
              label="Headset Make"
              type="string"
              required = {values.headSet}
              inputProps={{ maxLength: 15 }}
              InputLabelProps={{
                shrink: true,
              }}
              value= {values.headsetMake}
              onChange = {handleChange('headsetMake')}
              style={{left: '64px', marginLeft: '120px'}}
            ></TextField> : null }
             {values.headSet ?
             <TextField
              id="headset-model"
              label="Headset Model"
              type="string"
              inputProps={{ maxLength: 15 }}
              InputLabelProps={{
                shrink: true,
              }}
              required = {values.headSet}
              value= {values.headsetModel}
              onChange = {handleChange('headsetModel')}
              style={{left: '64px', marginLeft: '120px'}}
            ></TextField> : null }

          </div>
          <div className="form-wrapper">
          <div className="mui-custom-form" style={{marginLeft: '58px', marginRight: '0px'}}>
              <label className="MuiFormLabel-root small-label no-margin">
                Laptop/Computer
              </label>
              <div className="sub-radio">
                <Radio name="laptop" value="laptop" id="laptop" style ={{paddingLeft: '0px'}}
                 onChange = {handleChange('laptop')}
                 checked = {values.laptop}/>
                <label
                  for="laptop"
                  className="text-black"
                  style={{
                    fontSize: "14px",
                    fontWeight: "650",
                    color: "#274463",
                  }}
                >
                  Laptop
                </label>
                <Radio
                  className="ml-2"
                  name="computer"
                  value="computer"
                  id="Computer"
                  onChange = {handleChange('computer')}
                  checked = {values.computer}
                />
                <label
                  for="computer"
                  className="text-black"
                  style={{
                    fontSize: "14px",
                    fontWeight: "650",
                    color: "#274463",
                  }}
                >
                  Computer
                </label>
                <Radio name="laptop" value="laptop" id="laptop" style ={{paddingLeft: '0px'}}
                 onChange = {handleChange('none')}
                 checked = {values.none}/>
                <label
                  for="laptop"
                  className="text-black"
                  style={{
                    fontSize: "14px",
                    fontWeight: "650",
                    color: "#274463",
                  }}
                >
                  None
                </label>
              </div>
            </div>
            {values.laptop || values.computer ?
            <TextField
              id="asset-serial-number"
              label="Asset Serial Number"
              type="string"
              required = {values.laptop || values.computer}
              inputProps={{ maxLength: 15 }}
              InputLabelProps={{
                shrink: true,
              }}
              style={{left: '64px'}}
              values = {values.assetSerialNumber}
              onChange = {handleChange('assetSerialNumber')}
            ></TextField>
           : null }
            {values.laptop || values.computer ?
            <TextField
              id="asset-make"
              label="Asset Make"
              type="string"
              inputProps={{ maxLength: 15 }}
              InputLabelProps={{
                shrink: true,
              }}
              required = {values.laptop || values.computer}
              style={{left: '64px', marginLeft: '120px'}}
              values = {values.assetMake}
              onChange = {handleChange('assetMake')}
            ></TextField> : null }
             {values.laptop || values.computer ?
             <TextField
              id="asset-model"
              label="Asset Model"
              type="string"
              inputProps={{ maxLength: 15 }}
              InputLabelProps={{
                shrink: true,
              }}
              style={{left: '64px', marginLeft: '120px'}}
              values = {values.assetModel}
              onChange = {handleChange('assetModel')}
            ></TextField> : null }
          </div>
        </div>
      ) : (
        <div className = "asset-details">
            <div className="tab-heading float-left">
                {"Employee Asset Check list Software"}
            </div>
             <div className="form-wrapper">
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="software"
                control={<Checkbox color="primary" 
                checked={values.software}
                value = {values.software} 
                onChange = {handleChange('software')} />}
                label="Software(Licensed)"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="vdi"
                control={<Checkbox color="primary" 
                checked={values.vdi}
                value = {values.vdi} 
                onChange = {handleChange('vdi')}
                 />}
                label="VDI Access"
                labelPlacement="start"
              />
            </div>
            </div>
            <Table tableData = {rows} headCells = {headCells} />
        </div>
      )}
    </div>
  );
}

export default AssetDetails;

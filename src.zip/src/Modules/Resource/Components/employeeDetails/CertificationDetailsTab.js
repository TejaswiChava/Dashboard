import React from "react";
import TableComponent from "../../../../SharedModules/Table/Components/Table";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Radio from "@material-ui/core/Radio";


const headCells = [
  { id: "sno", numeric: false, disablePadding: true, label: "S no" },
  { id: "name", numeric: false, disablePadding: true, label: "Name" },
  { id: "date", numeric: true, disablePadding: false, label: "Date" },
  { id: "result", numeric: true, disablePadding: false, label: "Result" },
];

const rows = [
  {sno:"1", name: "HIPPA", date: "01/01/2020", result: "Qualified"},
  {sno: "2", name: "SAQ", date: "01/01/2020", result: "Qualified"},
  {sno: "3", name: "JAVA", date: "01/01/2020", result: "Qualified"},
  {sno: "4", name: "Angular", date: "01/01/2020", result: "Qualified"},
  {sno: "5", name: ".Net", date: "01/01/2020", result: "Qualified"},
];

function CertificationDetails(props) {
  const {values, handleChange, certificationTableRowClick, addCertificate, certificateTableData, isCertificateEdit} = props;
  let  tableData = [];
  tableData =  rows;
  

  return (
  <div>
    <div>
    <div className="form-wrapper">

          <div className="mui-custom-form">
            <TextField
              id="certification-name"
              fullWidth
              label="Name"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.certificationName}
              onChange={handleChange('certificationName')}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Date"
              fullWidth
              label="Date"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.certificationDate}
              onChange={handleChange('certificationDate')}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Result"
              fullWidth
              label="Result"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.certificationResult}
              onChange={handleChange('certificationResult')}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
    <Button
      className="btn-addEmployee"
      variant="contained"
      onClick = {addCertificate}
    >
      {isCertificateEdit ? 'Edit' : 'Add' }
    </Button>
        </div>

    </div>
    <TableComponent tableData={certificateTableData} headCells={headCells} onTableRowClick={certificationTableRowClick}/>
    
  </div>);
}
export default CertificationDetails;

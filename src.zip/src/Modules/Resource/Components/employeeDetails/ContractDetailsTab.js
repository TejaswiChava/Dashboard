import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";

function ContarctDetails(props) {
  const { values, handleChange, showContractDetailsError, showContractDetailsErrorMsg } = props;
  return (
    <div>
      <form autoComplete="off">
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="typeof-contract"
              fullWidth
              required
              label="Type Of Contract"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value={values.typeOfContract}
              onChange={handleChange('typeOfContract')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showContractDetailsError.showTypeOfContarctError
                  ? showContractDetailsErrorMsg.showTypeOfContractErrorMsg
                  : null
              }
              error={
                showContractDetailsError.showTypeOfContarctError
                  ? showContractDetailsErrorMsg.showTypeOfContractErrorMsg
                  : null
              }
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Program"
              fullWidth
              required
              label="Program"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.program}
              onChange={handleChange('program')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showContractDetailsError.showProgramError
                  ? showContractDetailsErrorMsg.showProgramErrorMsg
                  : null
              }
              error={
                showContractDetailsError.showProgramError
                  ? showContractDetailsErrorMsg.showProgramErrorMsg
                  : null
              }
            ></TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="cluster-name"
              fullWidth
              required
              label="Cluster Name"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value= {values.clusterName}
              onChange={handleChange('clusterName')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showContractDetailsError.showclusterNameError
                  ? showContractDetailsErrorMsg.showclusterNameErrorMsg
                  : null
              }
              error={
                showContractDetailsError.showclusterNameError
                  ? showContractDetailsErrorMsg.showclusterNameErrorMsg
                  : null
              }
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="sbu"
              fullWidth
              required
              label="SBU"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value= {values.sbu}
              onChange={handleChange('sbu')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showContractDetailsError.showSbuError
                  ? showContractDetailsErrorMsg.showSubErrorMsg
                  : null
              }
              error={
                showContractDetailsError.showSbuError
                  ? showContractDetailsErrorMsg.showSubErrorMsg
                  : null
              }
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form">
              <TextField
                id="cost-center"
                fullWidth
                label="Cost Center"
                type="string"
                inputProps={{ maxLength: 15 }}
                value={values.costCenter}
                onChange={handleChange('costCenter')}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="Lob-Head"
                fullWidth
                required
                label="Lob Head"
                type="string"
                select
                inputProps={{ maxLength: 15 }}
                value= {values.lobHead}
                onChange={handleChange('lobHead')}
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  showContractDetailsError.showLobHeadError
                    ? showContractDetailsErrorMsg.showLobHeadErrorMsg
                    : null
                }
                error={
                  showContractDetailsError.showLobHeadError
                    ? showContractDetailsErrorMsg.showLobHeadErrorMsg
                    : null
                }
              >
                <MenuItem
                  selected
                  key="Please Select"
                  value="Please Select"
                >
                  Please Select
                </MenuItem>
              </TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="Typeof-billing"
                fullWidth
                required
                label="Type of billing"
                type="string"
                select
                inputProps={{ maxLength: 15 }}
                value={values.typeOfBilling}
                onChange={handleChange('typeOfBilling')}
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  showContractDetailsError.showTypeOfBillingError
                    ? showContractDetailsErrorMsg.showTypeOfBillingErrorMsg
                    : null
                }
                error={
                  showContractDetailsError.showTypeOfBillingError
                    ? showContractDetailsErrorMsg.showTypeOfBillingErrorMsg
                    : null
                }
              >
                <MenuItem
                  selected
                  key="Please Select"
                  value="Please Select"
                >
                  Please Select
                </MenuItem>
              </TextField>
            </div>
            <div className="mui-custom-form">
              <TextField
                id="Crid"
                fullWidth
                required
                label="CR Id"
                type="string"
                inputProps={{ maxLength: 15 }}
                value={values.crId}
                onChange={handleChange('crId')}
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  showContractDetailsError.showCrIdError
                    ? showContractDetailsErrorMsg.showCrIdErrorMsg
                    : null
                }
                error={
                  showContractDetailsError.showCrIdError
                    ? showContractDetailsErrorMsg.showCrIdErrorMsg
                    : null
                }
              ></TextField>
            </div>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form">
              <TextField
                id="Purchaser-order"
                fullWidth
                required
                label="Purchase Order"
                type="string"
                inputProps={{ maxLength: 15 }}
                value={values.purchaseOrder}
                onChange={handleChange('purchaseOrder')}
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  showContractDetailsError.showPurchaseOrderError
                    ? showContractDetailsErrorMsg.showPurchaseOrderErrorMsg
                    : null
                }
                error={
                  showContractDetailsError.showPurchaseOrderError
                    ? showContractDetailsErrorMsg.showPurchaseOrderErrorMsg
                    : null
                }
              ></TextField>
            </div>
            <div className="mui-custom-form">
              <TextField
                id="Position-Id"
                fullWidth
                required
                label="Position Id"
                type="string"
                inputProps={{ maxLength: 15 }}
                value={values.positionId}
                onChange={handleChange('positionId')}
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  showContractDetailsError.showPositionidError
                    ? showContractDetailsErrorMsg.showPositionidErrorMsg
                    : null
                }
                error={
                  showContractDetailsError.showPositionidError
                    ? showContractDetailsErrorMsg.showPositionidErrorMsg
                    : null
                }
              ></TextField>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
export default ContarctDetails;

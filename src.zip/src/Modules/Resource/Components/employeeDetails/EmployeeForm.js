import React, { useState } from "react";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import AppBar from "@material-ui/core/AppBar";
import { makeStyles } from "@material-ui/core/styles";
import TabPanel from "../../../../SharedModules/TabPanel/TabPanel";
import EmployeeDetails from "./EmplyeeDetailsTab";
import ContractDetails from "./ContractDetailsTab";
import OtherDetails from "./OtherDetailsTab";
import VendorDetails from "./VendorDetailsTab";
import SkillSetDetails from "./SkillSetDetailsTab";
import CertificationDetails from "./CertificationDetailsTab";
import AssetDetails from "./AssetDetailsTab";
import "../employeeDetails.scss";
import { Button } from 'react-bootstrap';
import {cidRequired, conduentEmailRequired, contactNumberRequired, firstNameRequired, lastNameRequired,
  typeOfBillingRequired, typeOfContarctRequired, crIdRequired, positionIdRequired, purchaseOrderRequired,
  sbuRequired, lobRequired, worklocationRequired, floorRequired, seatTypeRequired, seatNumberRequired,
  occupiedRequired, shiftTimingsRequired, vendorNameRequired, vendorEmpIdRequired, vendorEmailRequired,
  vendorUnitRequired, empHidRequired, headSetMakeRequired, headSetSerialRequired, headSetModelRequired,
  assetMakeRequired, assetSerialRequired, assetModelRequired, programRequired, clusterNameRequired, 
 } from './validation';

const useStyles = makeStyles({
  tab100: {
    minWidth: 0,
  },
});

function EmployeeAdd() {
  const classes = useStyles();

  // Tab Value
  const [value, setValue] = useState(0);

  // Tab Change Event
  const handleChangeTabs = (event, newValue) => {
    setValue(newValue);
  };

  // input Vlaues 
  const [values, setValues] =  useState({
    seccuredPassPhrase: false,
    lan: false,
    employeeIdCard: false,
    companyCreditCard: false,
    manualDocuments: false,
    telephoneCard: false,
    airTravelCards: false,
    officekeys: false,
    voiceMail: false,
    headSet:  false,
    pager: false,
    laptop: false,
    computer: false,
    none: false,
    cid: '',
    contactNumber: '',
    conduentEmail: '',
    conduentManagerEmail: '',
    firstName:'',
    lastName: '',
    middleName: '',
    conduentVendorEmailId: '',
    typeOfContract: 'Please Select',
    program:'',
    clusterName: 'Please Select',
    sbu: 'Please Select',
    costCenter:'',
    lobHead: 'Please Select',
    typeOfBilling: 'Please Select',
    crId: '',
    purchaseOrder: '',
    positionId: '',
    workLocation: 'Please Select',
    building: '',
    floor:'Please Select',
    seatType: 'Please Select',
    seatNumber: '',
    occupied: 'Please Select',
    shiftTimings: 'Please Select',
    vendorName: 'Please Select',
    vendorEmployeeId: '',
    vendorEmployeeEmail: '',
    vendorUnit: 'Please Select',
    vendorManagerEmail: '',
    vendorAccountMangerEmail: '',
    skill:'',
    certificationName: '',
    certificationDate: '',
    certificationResult: '',
    software: false,
    vdi: false,
    employeeHidNumber: '',
    headsetSerialNumber: '',
    headsetMake: '',
    headsetModel: '',
    assetSerialNumber: '',
    assetMake: '',
    assetModel: ''
  })

const [isCertificateEdit, setCertificateEdit] = useState(false);
const [showEmpDetailsError, setShowEmpDetailsError] = useState({
  showCidError: false,
  showContactNumberError: false,
  showCNDTEmailError: false,
  showFirstNameError: false,
  showLastNameError: false
});
const [showContractDetailsError, setShowContractDetailsError] = useState({
  showTypeOfContarctError:  false,
  showProgramError: false,
  showClusterNameError: false,
  showSbuError: false,
  showLobHeadError: false,
  showTypeOfBillingError: false,
  showCrIdError: false,
  showPurchaseOrderError: false,
  showPositionidError: false
});
const [showOtherDetailsError, setShowOtherDetailsError] = useState({
  showWorkLocationError: false,
  showFloorError: false,
  showSeatTypeError: false,
  showSeatNumberError: false,
  showOccupiedError: false,
  showShiftError: false
});
const [showVendorDetailsError, setShowVendorDetailsError] = useState({
  showVendorNameError: false,
  showVendorEmpIdError: false,
  showVendorEmpEmailError: false,
  showVendorUnitError: false
});
const [showAssetError, setShowAsssetError] = useState({
  showEmpHidError: false,
  showHeadSetSerialError: false,
  showHeadSetMakeError: false,
  showHeadSetModelError: false,
  showAssetSerialError: false,
  showAssetMakeError: false,
  showAssetModelError: false
})
const [showEmpDetailsErrorMsg, setShowEmpDetailsErrorMsg] = useState({
  showCidErrorMsg: '',
  showContactNumberErrorMsg: '',
  showCNDTEmailErrorMsg: '',
  showFirstNameErrorMsg: '',
  showLastNameErrorMsg: ''
});
const [showContractDetailsErrorMsg, setShowContractDetailsErrorMsg] = useState({
  showTypeOfContractErrorMsg: '',
  showProgramErrorMsg: '',
  showClusterNameErrorMsg: '',
  showSubErrorMsg: '',
  showLobHeaderErrorMsg: '',
  showTypeOfBillingErrorMsg: '',
  showCrIdErrorMsg: '',
  showPurchaseOrderErrorMsg: '',
  showPositionidErrorMsg: ''
});

const [showOtherDetailsErrorMsg, setShowOtherDetailsErrorMsg] = useState({
  showWorkLocationErrorMsg: '',
  showFloorErrorMsg: '',
  showSeatTypeErrorMsg: '',
  showSeatNumberErrorMsg: '',
  showOccupiedErrorMsg: '',
  showShiftErrorMsg: ''
});
const [showVendorDetailsErrorMsg, setShowVendorDetailsErrorMsg] = useState({
  showVendorNameErrorMsg: '',
  showVendorEmpIdErrorMsg: '',
  showVendorEmpEmailErrorMsg: '',
  showVendorUnitErrorMsg: ''
});
const [showAssetDetailsErrorMsg, setShowAssetDetailErrorMsg] = useState({
  showEmpHidErrorMsg: '',
  showHeadSetSerialErrorMsg: '',
  showHeadSetMakeErrorMsg: '',
  showHeadSetModelErrorMsg: '',
  showAssetSerialErrorMsg: '',
  showAssetMakeErrorMsg: '',
  showAssetModelErrorMsg: ''
})

  // handle change inputs

  const handleChange = name => event => {
   if(name == 'seccuredPassPhrase') {
     setValues({...values, seccuredPassPhrase: !values.seccuredPassPhrase})
   }
   else if(name == 'lan') {
    setValues({...values, lan: !values.lan})
  }
  else if(name == 'employeeIdCard') {
    setValues({...values, employeeIdCard: !values.employeeIdCard})
  }
  else if(name == 'companyCreditCard') {
    setValues({...values, companyCreditCard: !values.companyCreditCard})
  }
  else if(name == 'manualDocuments') {
    setValues({...values, manualDocuments: !values.manualDocuments})
  }
  else if(name == 'telephoneCard') {
    setValues({...values, telephoneCard: !values.telephoneCard})
  }
  else if(name == 'airTravelCards') {
    setValues({...values, airTravelCards: !values.airTravelCards})
  }
  else if(name == 'officekeys') {
    setValues({...values, officekeys: !values.officekeys})
  }
  else if(name == 'headSet') {
    setValues({...values, headSet: !values.headSet})
  }
  else if(name == 'pager') {
    setValues({...values, pager: !values.pager})
  }
  else if(name == 'none') {
    setValues({...values, computer: false, laptop: false, none: !values.none})
  }
  else if(name == 'computer') {
    setValues({...values, computer: !values.computer, laptop: false, none: false})
  }
  else if(name == 'laptop') {
    setValues({...values, laptop: !values.laptop, computer: false, none: false})
  } else {
    setValues({...values, [name]: event.target.value})
  }
  }
  const certificationTableRowClick = row  => {
    setCertificateEdit(true);
    setValues({...values, certificationDate: row.date, certificationName: row.name, certificationResult: row.result})
  }
  const certificateTableData = [
    {sno:"1", name: "HIPPA", date: "01/01/2020", result: "Qualified"},
    {sno: "2", name: "SAQ", date: "01/01/2020", result: "Qualified"},
    {sno: "3", name: "JAVA", date: "01/01/2020", result: "Qualified"},
    {sno: "4", name: "Angular", date: "01/01/2020", result: "Qualified"},
    {sno: "5", name: ".Net", date: "01/01/2020", result: "Qualified"},
  ]
  const addCertificate = () => {
    setCertificateEdit(false);
    let name = values.certificationName;
    let date = values.certificationDate;
    let result = values.certificationResult
    let tableRowObj = {
      sno: '6',
      name: name,
      date: date,
      result: result
    }
    certificateTableData.push(tableRowObj);
  }

  const masterSave = () => {
    var showCidError = false; var showContactNumberError = false; var showCNDTEmailError = false;
    var showFirstNameError = false; var showLastNameError = false; var showTypeOfContarctError = false;
    var showProgramError = false; var showClusterNameError = false; var showSbuError = false;
    var showLobHeadError = false; var showTypeOfBillingError = false; var showCrIdError = false;
    var showPurchaseOrderError = false; var showPositionidError = false; var showWorkLocationError = false;
    var showFloorError = false; var showSeatTypeError = false; var showSeatNumberError = false;
    var showOccupiedError = false; var showShiftError = false; var showVendorNameError= false;
    var showVendorEmpIdError= false; var showVendorEmpEmailError=  false; var showVendorUnitError= false;
    var showEmpHidError=  false; var showHeadSetSerialError= false;  var showHeadSetMakeError= false;
    var showHeadSetModelError=  false; var showAssetSerialError = false; var showAssetMakeError = false;
    var showAssetModelError= false
    var showCidErrorMsg = ''; var showContactNumberErrorMsg = ''; var showCNDTEmailErrorMsg = '';
    var showFirstNameErrorMsg = ''; var showLastnameErrorMsg = ''; var showTypeOfContractErrorMsg = '';
    var showProgramErrorMsg = ''; var showClusterNameErrorMsg = ''; var showSubErrorMsg = '';
    var showLobHeaderErrorMsg = ''; var  showTypeOfBillingErrorMsg = '';
    var showCrIdErrorMsg = ''; var showPurchaseOrderErrorMsg = ''; var showPositionidErrorMsg = '';
    var showWorkLocationErrorMsg = ''; var showFloorErrorMsg = ''; var showSeatTypeErroMsg = '';
    var showSeatNumberErrorMsg = ''; var  showOccupiedErrorMsg = ''; var showShiftErrorMsg = '';
    var showVendorNameErrorMsg = ''; var showVendorEmpIdErrorMsg= ''; var showVendorEmpEmailErrorMsg='';
    var showVendorUnitErrorMsg = '';  var showEmpHidErrorMsg= ''; var showHeadSetSerialErrorMsg=  '';
    var showHeadSetMakeErrorMsg= ''; var showHeadSetModelErrorMsg= ''; var showAssetSerialErrorMsg= '';
    var showAssetMakeErrorMsg= ''; var showAssetModelErrorMsg= ''; var showSeatTypeErrorMsg = ''
    if(cidRequired(values.cid)) {
      showCidError = true;
      showCidErrorMsg = 'CID Required.';
    }

    if(contactNumberRequired(values.contactNumber)) {
      showContactNumberError = true;
      showContactNumberErrorMsg = 'Contact Number Required.';
    }

    if(conduentEmailRequired(values.conduentEmail)) {
      showCNDTEmailError = true;
      showCNDTEmailErrorMsg = 'Conduent Email Required.';
    }

    if(firstNameRequired(values.firstName)) {
      showFirstNameError = true;
      showFirstNameErrorMsg = 'First Name Required.';
    }

    if(lastNameRequired(values.lastName)) {
      showLastNameError = true;
      showLastnameErrorMsg = 'Last Name Required.';
    }

    if(typeOfContarctRequired(values.lastName)) {
      showTypeOfContarctError = true;
      showTypeOfContractErrorMsg = 'Type of contract Required.';
    }

    if(programRequired(values.program)) {
      showProgramError = true;
      showProgramErrorMsg = 'Program is required.';
    }

    if(clusterNameRequired(values.clusterName)) {
      showClusterNameError = true;
      showClusterNameErrorMsg = 'Cluster Name is required.';
    }

    if(sbuRequired(values.sbu)) {
      showSbuError = true;
      showSubErrorMsg = 'Sbu is required';
    }

    if(lobRequired(values.lobHead)) {
      showLobHeadError = true;
      showLobHeaderErrorMsg = 'Lob Head is required';
    }

    if(typeOfBillingRequired(values.typeOfBilling)) {
      showTypeOfBillingError = true;
      showTypeOfBillingErrorMsg = 'Type of billing is required.'
    }

    if(crIdRequired(values.crId)) {
      showCrIdError = true;
      showCrIdErrorMsg = 'Cr Id is required.'
    }

    if(purchaseOrderRequired(values.purchaseOrder)) {
      showPurchaseOrderError = true;
      showPurchaseOrderErrorMsg = 'Purchase Order reuired.'
    }

    if(positionIdRequired(values.positionId)){
      showPositionidError = true;
      showPositionidErrorMsg = 'Position Id required.'
    }

    if(worklocationRequired(values.workLocation)) {
      showWorkLocationError = true;
      showWorkLocationErrorMsg = 'Work location is required.'
    }

    if(floorRequired(values.floor)) {
      showFloorError = true;
      showFloorErrorMsg = 'Floor is required.'
    }

    if(seatTypeRequired(values.seatType)) {
      showSeatTypeError = true;
      showSeatTypeErrorMsg = 'Seat type is required.'
    }

    if(seatNumberRequired(values.seatNumber)) {
      showSeatNumberError = true;
      showSeatNumberErrorMsg = 'Seat  Number is required.'
    }

    if(occupiedRequired(values.occupied)) {
      showOccupiedError = true;
      showOccupiedErrorMsg = 'Occupied is required.'
    }

    if(shiftTimingsRequired(values.shiftTimings)) {
      showShiftError = true;
      showShiftErrorMsg = 'Shift timings is required.'
    }

    if(vendorNameRequired(values.vendorName)) {
      showVendorNameError = true;
      showVendorNameErrorMsg = 'Vendor name is required.'
    }

    if(vendorEmpIdRequired(values.vendorEmployeeId)) {
      showVendorEmpIdError = true;
      showVendorEmpIdErrorMsg = 'Vendor emp id is required.'
    }

    if(vendorEmailRequired(values.vendorEmployeeEmail)) {
      showVendorEmpEmailError = true;
      showVendorEmpEmailErrorMsg = 'Vendor emp email id is required.'
    }

    if(vendorUnitRequired(values.vendorUnit)) {
      showVendorUnitError = true;
      showVendorUnitErrorMsg = 'Vendor unit is required.'
    }

    if(empHidRequired(values.employeeHidNumber)) {
      showEmpHidError = true;
      showEmpHidErrorMsg = 'Emp Hid is required.'
    }

    if(headSetSerialRequired(values.headsetSerialNumber)) {
      showHeadSetSerialError = true;
      showHeadSetSerialErrorMsg = 'Head set serial is required.'
    }

    if(headSetMakeRequired(values.headsetMake)) {
      showHeadSetMakeError = true;
      showHeadSetMakeErrorMsg = 'Head set make is required.'
    }

    if(headSetModelRequired(values.headsetModel)) {
      showHeadSetModelError = true;
      showHeadSetModelErrorMsg = 'Head set model is required.'
    }

    if(assetSerialRequired(values.assetSerialNumber)) {
      showAssetSerialError = true;
      showAssetSerialErrorMsg = 'Asset serial is required.'
    }

    if(assetMakeRequired(values.assetMake)) {
      showAssetMakeError = true;
      showAssetMakeErrorMsg = 'Asset make is required.'
    }

    if(assetModelRequired(values.assetModel)) {
      showAssetModelError = true;
      showAssetModelErrorMsg = 'Asset model is required.'
    }

  
    setShowEmpDetailsError({
      showCidError: showCidError,
      showContactNumberError: showContactNumberError,
      showCNDTEmailError: showCNDTEmailError,
      showFirstNameError: showFirstNameError,
      showLastNameError: showLastNameError
    });

    setShowEmpDetailsErrorMsg({
      showCidErrorMsg: showCidErrorMsg,
      showContactNumberErrorMsg: showContactNumberErrorMsg,
      showCNDTEmailErrorMsg: showCNDTEmailErrorMsg,
      showFirstNameErrorMsg: showFirstNameErrorMsg,
      showLastNameErrorMsg: showLastnameErrorMsg
    });

    setShowContractDetailsError({
      showTypeOfContarctError:  showTypeOfContarctError,
      showProgramError: showProgramError,
      showClusterNameError: showClusterNameError,
      showSbuError: showSbuError,
      showLobHeadError: showLobHeadError,
      showTypeOfBillingError: showTypeOfBillingError,
      showCrIdError: showCrIdError,
      showPurchaseOrderError: showPurchaseOrderError,
      showPositionidError: showPositionidError
    });
    setShowContractDetailsErrorMsg({
      showTypeOfContractErrorMsg: showTypeOfContractErrorMsg,
      showProgramErrorMsg: showProgramErrorMsg,
      showClusterNameErrorMsg: showClusterNameErrorMsg,
      showSubErrorMsg: showSubErrorMsg,
      showLobHeaderErrorMsg: showLobHeaderErrorMsg,
      showTypeOfBillingErrorMsg: showTypeOfBillingErrorMsg,
      showCrIdErrorMsg: showCrIdErrorMsg,
      showPurchaseOrderErrorMsg: showPurchaseOrderErrorMsg,
      showPositionidErrorMsg: showPositionidErrorMsg

    });
    setShowOtherDetailsError({
      showWorkLocationError: showWorkLocationError,
      showFloorError: showFloorError,
      showSeatTypeError: showSeatTypeError,
      showSeatNumberError: showSeatNumberError,
      showOccupiedError: showOccupiedError,
      showShiftError: showShiftError

    });
    setShowOtherDetailsErrorMsg({
      showWorkLocationErrorMsg: showWorkLocationErrorMsg,
      showFloorErrorMsg: showFloorErrorMsg,
      showSeatTypeErrorMsg: showSeatTypeErroMsg,
      showSeatNumberErrorMsg: showSeatNumberErrorMsg,
      showOccupiedErrorMsg: showOccupiedErrorMsg,
      showShiftErrorMsg: showShiftErrorMsg
    });
    setShowVendorDetailsError({
      showVendorNameError: showVendorNameError,
      showVendorEmpIdError: showVendorEmpIdError,
      showVendorEmpEmailError: showVendorEmpEmailError,
      showVendorUnitError: showVendorUnitError
    });
    setShowVendorDetailsErrorMsg({
      showVendorNameErrorMsg: showVendorNameErrorMsg,
      showVendorEmpIdErrorMsg: showVendorEmpIdErrorMsg,
      showVendorEmpEmailErrorMsg: showVendorEmpEmailErrorMsg,
      showVendorUnitErrorMsg: showVendorUnitErrorMsg
    });
    setShowAsssetError({
      showEmpHidError: showEmpHidError,
      showHeadSetSerialError: showHeadSetSerialError,
      showHeadSetMakeError: showHeadSetMakeError,
      showHeadSetModelError: showHeadSetModelError,
      showAssetSerialError: showAssetSerialError,
      showAssetMakeError: showAssetMakeError,
      showAssetModelError: showAssetModelError
    });
    setShowAssetDetailErrorMsg({
      showEmpHidErrorMsg: showEmpHidErrorMsg,
      showHeadSetSerialErrorMsg: showHeadSetSerialErrorMsg,
      showHeadSetMakeErrorMsg: showHeadSetMakeErrorMsg,
      showHeadSetModelErrorMsg: showHeadSetModelErrorMsg,
      showAssetSerialErrorMsg: showAssetSerialErrorMsg,
      showAssetMakeErrorMsg: showAssetMakeErrorMsg,
      showAssetModelErrorMsg: showAssetModelErrorMsg
    })
  }
  return (
    <div className="pos-relative w-100 h-100">
      <div className="tabs-container">
        <div className="tab-header">
          <div className="tab-heading float-left">{"Add Employee"}</div>
          <div className="float-right mt-2">
            <Button className='btn  ml-1' onClick={masterSave}>
              <i class="fa fa-check" aria-hidden="true"></i>
              Save
            </Button>
            </div>
        </div>
        <div className="tab-body">
          <EmployeeDetails values = { values } handleChange = { handleChange } 
          
          showEmpDetailsError= {showEmpDetailsError} showEmpDetailsErrorMsg = {showEmpDetailsErrorMsg}
          />
          <div className="tab-panelbody">
            <div className="tab-holder mb-3 mt-2">
              <AppBar position="static">
                <Tabs
                  variant="fullWidth"
                  value={value}
                  onChange={handleChangeTabs}
                  aria-label="simple tabs example"
                >
                  <Tab
                    label="Contract Details"
                    classes={{ root: classes.tab100 }}
                  />
                  <Tab
                    label="Other Details"
                    classes={{ root: classes.tab100 }}
                  />
                  <Tab
                    label="Vendor Details"
                    classes={{ root: classes.tab100 }}
                  />
                  <Tab label="Skill Set" classes={{ root: classes.tab100 }} />
                  <Tab
                    label="Certification"
                    classes={{ root: classes.tab100 }}
                  />
                  <Tab label="Assets" classes={{ root: classes.tab100 }} />
                </Tabs>
              </AppBar>
              <TabPanel value={value} index={0}>
                <div className="tab-holder my-3 p-0">
                  <ContractDetails values = { values } handleChange = { handleChange } showContractDetailsError= {showContractDetailsError} showContractDetailsErrorMsg= {showContractDetailsErrorMsg}/>
                </div>
              </TabPanel>
              <TabPanel value={value} index={1}>
                <div className="tab-holder my-3 p-0">
                  <OtherDetails values = { values } handleChange = { handleChange } showOtherDetailsErrorMsg = {showOtherDetailsErrorMsg} showOtherDetailsError = {showOtherDetailsError}/>
                </div>
              </TabPanel>
              <TabPanel value={value} index={2}>
                <div className="tab-holder my-3 p-0">
                  <VendorDetails values = { values } handleChange = { handleChange } showVendorDetailsError = {showVendorDetailsError} showVendorDetailsErrorMsg = {showVendorDetailsErrorMsg}/>
                </div>
              </TabPanel>
              <TabPanel value={value} index={3}>
                <div className="tab-holder my-3 p-0">
                  <SkillSetDetails values = { values } handleChange = { handleChange }/>
                </div>
              </TabPanel>
              <TabPanel value={value} index={4}>
                <div className="tab-holder my-3 p-0">
                  <CertificationDetails values = { values } handleChange = { handleChange } certificationTableRowClick= {certificationTableRowClick} addCertificate={addCertificate} certificateTableData= {certificateTableData} isCertificateEdit={isCertificateEdit}/>
                </div>
              </TabPanel>
              <TabPanel value={value} index={5}>
                <div className="tab-holder my-3 p-0">
                  <AssetDetails values = { values } handleChange = { handleChange } showAssetError = {showAssetError}
                  showAssetDetailsErrorMsg = {showAssetDetailsErrorMsg}
                  />
                </div>
              </TabPanel>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EmployeeAdd;

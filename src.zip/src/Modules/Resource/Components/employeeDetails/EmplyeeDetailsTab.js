import React from "react";
import TextField from "@material-ui/core/TextField";

function EmployeeDetailsTab(props) {
  const { values, handleChange, showEmpDetailsError, showEmpDetailsErrorMsg} = props;
  return (
    <div>
      <form autoComplete="off">
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="CID"
              fullWidth
              required
              label="CID"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.cid}
              onChange={handleChange('cid')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showEmpDetailsError.showCidError
                  ? showEmpDetailsErrorMsg.showCidErrorMsg
                  : null
              }
              error={
                showEmpDetailsError.showCidError
                  ? showEmpDetailsErrorMsg.showCidErrorMsg
                  : null
              }
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Contact-number"
              fullWidth
              required
              label="Contact Number"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.contactNumber}
              onChange={handleChange('contactNumber')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showEmpDetailsError.showContactNumberError
                  ? showEmpDetailsErrorMsg.showContactNumberErrorMsg
                  : null
              }
              error={
                showEmpDetailsError.showContactNumberError
                  ? showEmpDetailsErrorMsg.showContactNumberErrorMsg
                  : null
              }
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Conduent-email"
              fullWidth
              label="Conduent Email"
              type="string"
              required
              inputProps={{ maxLength: 15 }}
              value={values.conduentEmail}
              onChange={handleChange('conduentEmail')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showEmpDetailsError.showCNDTEmailError
                  ? showEmpDetailsErrorMsg.showCNDTEmailErrorMsg
                  : null
              }
              error={
                showEmpDetailsError.showCNDTEmailError
                  ? showEmpDetailsErrorMsg.showCNDTEmailErrorMsg
                  : null
              }
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Conduent-manager-email"
              fullWidth
              label="Conduent Manager Email"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.conduentManagerEmail}
              onChange={handleChange('conduentManagerEmail')}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
        </div>
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="First-Name"
              fullWidth
              required
              label="First Name"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.firstName}
              onChange={handleChange('firstName')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showEmpDetailsError.showFirstNameError
                  ? showEmpDetailsErrorMsg.showFirstNameErrorMsg
                  : null
              }
              error={
                showEmpDetailsError.showFirstNameError
                  ? showEmpDetailsErrorMsg.showFirstNameErrorMsg
                  : null
              }
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Middle-name"
              fullWidth
              label="Middle Name"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.middleName}
              onChange={handleChange('middleName')}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Last-Name"
              fullWidth
              required
              label="Last Name"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.lastName}
              onChange={handleChange('lastName')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showEmpDetailsError.showLastNameError
                  ? showEmpDetailsErrorMsg.showLastNameErrorMsg
                  : null
              }
              error={
                showEmpDetailsError.showLastNameError
                  ? showEmpDetailsErrorMsg.showLastNameErrorMsg
                  : null
              }
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Conduent-vendor-manager-email"
              fullWidth
              label="Conduent Vendor Manager Email"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.conduuentVendorManagerEmail}
              onChange={handleChange('conduuentVendorManagerEmail')}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
        </div>
      </form>
    </div>
  );
}

export default EmployeeDetailsTab;

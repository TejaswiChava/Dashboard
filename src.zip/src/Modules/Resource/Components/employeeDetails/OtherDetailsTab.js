import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";

function OtherDetails(props) {
  const { values, handleChange, showOtherDetailsError, showOtherDetailsErrorMsg } = props;
  return (
    <div>
      <form autoComplete="off">
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="work-location"
              fullWidth
              required
              label="Work location"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value={values.workLocation}
              onChange={handleChange('workLocation')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showOtherDetailsError.showWorkLcoationError
                ? showOtherDetailsErrorMsg.showWorkLcoationErrorMsg
                : null
              }
              error={
                showOtherDetailsError.showWorkLcoationError
                  ? showOtherDetailsErrorMsg.showWorkLcoationErrorMsg
                  : null
              }
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="building"
              fullWidth
              label="Building"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.building}
              onChange={handleChange('building')}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="floor"
              fullWidth
              required
              label="Floor"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value={values.floor}
              onChange={handleChange('floor')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showOtherDetailsError.showFloorError
                ? showOtherDetailsErrorMsg.showFloorErrorMsg
                : null
              }
              error={
                showOtherDetailsError.showFloorError
                  ? showOtherDetailsErrorMsg.showFloorErrorMsg
                  : null
              }
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="seat-type"
              fullWidth
              required
              label="Seat Type"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value={values.seatType}
              onChange={handleChange('seatType')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showOtherDetailsError.showSeatTypeError
                ? showOtherDetailsErrorMsg.showSeatTypeErrorMsg
                : null
              }
              error={
                showOtherDetailsError.showSeatTypeError
                  ? showOtherDetailsErrorMsg.showSeatTypeErrorMsg
                  : null
              }
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form">
              <TextField
                id="seat-number"
                fullWidth
                required
                label="Seat Number"
                type="string"
                inputProps={{ maxLength: 15 }}
                value={values.seatNumber}
                onChange={handleChange('seatNumber')}
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  showOtherDetailsError.showSeatNumberError
                  ? showOtherDetailsErrorMsg.showSeatNumberErrorMsg
                  : null
                }
                error={
                  showOtherDetailsError.showSeatNumberError
                  ? showOtherDetailsErrorMsg.showSeatNumberErrorMsg
                  : null
                }
              ></TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="occupied"
                fullWidth
                required
                label="Occupied ?"
                type="string"
                select
                inputProps={{ maxLength: 15 }}
                value={values.occupied}
                onChange={handleChange('occupied')}
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  showOtherDetailsError.showOccupiedError
                  ? showOtherDetailsErrorMsg.showOccupiedErrorMsg
                  : null
                }
                error={
                  showOtherDetailsError.showOccupiedError
                  ? showOtherDetailsErrorMsg.showOccupiedErrorMsg
                  : null
                }
              >
                <MenuItem
                  selected
                  key="Please Select"
                  value="Please Select"
                >
                  Please Select
                </MenuItem>
              </TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="shift-timings"
                fullWidth
                required
                label="Shift Timings"
                type="string"
                select
                inputProps={{ maxLength: 15 }}
                value={values.shiftTimings}
                onChange={handleChange('shiftTimings')}
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  showOtherDetailsError.showShiftError
                    ? showOtherDetailsErrorMsg.showShiftErrorMsg
                    : null
                }
                error={
                  showOtherDetailsError.showShiftError
                  ? showOtherDetailsErrorMsg.showShiftErrorMsg
                  : null
                }
              >
                <MenuItem
                  selected
                  key="Please Select"
                  value="Please Select"
                >
                  Please Select
                </MenuItem>
              </TextField>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
export default OtherDetails;

import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";

function VendorDetails(props) {
  const { values, handleChange, showVendorDetailsError, showVendorDetailsErrorMsg } = props;
  return (
    <div>
      <form autoComplete="off">
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="vendor-name"
              fullWidth
              required
              label="Vendor Name"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
                value= {values.vendorName}
              onChange={handleChange('vendorName')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showVendorDetailsError.showVendorNameError
                  ? showVendorDetailsErrorMsg.showVendorNameErrorMsg
                  : null
              }
              error={
                showVendorDetailsError.showVendorNameError
                  ? showVendorDetailsErrorMsg.showVendorNameErrorMsg
                  : null
              }
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="vendor-employee-id"
              fullWidth
              required
              label="Vendor Employee Id"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.vendorEmployeeId}
              onChange={handleChange('vendorEmployeeId')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showVendorDetailsError.showVendorEmpIdError
                  ? showVendorDetailsErrorMsg.showVendorEmpIdErrorMsg
                  : null
              }
              error={
                showVendorDetailsError.showVendorEmpIdError
                  ? showVendorDetailsErrorMsg.showVendorEmpIdErrorMsg
                  : null
              }
            ></TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="vendor-employee-email"
              fullWidth
              required
              label="Vendor Emplyee Email"
              type="string"
              inputProps={{ maxLength: 15 }}
              value={values.vendorEmployeeEmail}
              onChange={handleChange('vendorEmployeeEmail')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showVendorDetailsError.showVendorEmpEmailError
                  ? showVendorDetailsErrorMsg.showVendorEmpEmailErrorMsg
                  : null
              }
              error={
                showVendorDetailsError.showVendorEmpEmailError
                  ? showVendorDetailsErrorMsg.showVendorEmpEmailErrorMsg
                  : null
              }
            ></TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="Vendor-Unit"
              fullWidth
              required
              label="Vendor Unit"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value= {values.vendorUnit}
              onChange={handleChange('vendorUnit')}
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                showVendorDetailsError.showVendorUnitError
                ? showVendorDetailsErrorMsg.showVendorUnitErrorMsg
                : null
              }
              error={
                showVendorDetailsError.showVendorUnitError
                  ? showVendorDetailsErrorMsg.showVendorUnitErrorMsg
                  : null
              }
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form">
              <TextField
                id="vendor-manager-email"
                fullWidth
                label="Vendor manager Email"
                type="string"
                inputProps={{ maxLength: 15 }}
                value={values.vendorManagerEmail}
                onChange={handleChange('vendormanagerEmail')}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="vendor-account-manager-email"
                fullWidth
                label="Vendor account manager email"
                type="string"
                inputProps={{ maxLength: 15 }}
                value={values.vendorAccountManagerEmail}
                onChange={handleChange('vendorAccountManagerEmail')}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
export default VendorDetails;

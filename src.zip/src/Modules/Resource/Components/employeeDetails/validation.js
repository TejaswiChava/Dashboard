import React from 'react';

export const cidRequired = (value) => {
    let isCidValid = false;
    if(value === '') {
        isCidValid = true;
    }
    return isCidValid;
}

export const contactNumberRequired = (value) => {
    let isContactNumberValid = false;
    if(value === '') {
        isContactNumberValid = true;
    }
    return isContactNumberValid;
}

export const conduentEmailRequired = (value) => {
    let isConduentEmailValid = false;
    if(value === '') {
        isConduentEmailValid = true;
    }
    return isConduentEmailValid;
}

export const firstNameRequired = (value) => {
    let isFirstNameValid = false;
    if(value === '') {
        isFirstNameValid = true;
    }
    return isFirstNameValid;
}

export const lastNameRequired = (value) => {
    let isLastNameValid = false;
    if(value === '') {
        isLastNameValid = true;
    }
    return isLastNameValid;
}


export const typeOfContarctRequired = (value) => {
    let istypeOfContractValid = false;
    if(value === 'Please Select') {
        istypeOfContractValid = true;
    }
    return istypeOfContractValid;
}

export const programRequired = (value) => {
    let isProgramValid = false;
    if(value === '') {
        isProgramValid = true;
    }
    return isProgramValid;
}

export const clusterNameRequired = (value) => {
    let isClusterNameValid = false;
    if(value === 'Please Select') {
        isClusterNameValid = true;
    }
    return isClusterNameValid;
}

export const sbuRequired = (value) => {
    let isSbuValid = false;
    if(value === 'Please Select') {
        isSbuValid = true;
    }
    return isSbuValid;
}

export const lobRequired = (value) => {
    let isLobValid = false;
    if(value === 'Please Select') {
        isLobValid = true;
    }
    return isLobValid;
}

export const typeOfBillingRequired = (value) => {
    let istypeOfBillingValid = false;
    if(value === 'Please Select') {
        istypeOfBillingValid = true;
    }
    return istypeOfBillingValid;
}

export const crIdRequired = (value) => {
    let iscrIdValid = false;
    if(value === '') {
        iscrIdValid = true;
    }
    return iscrIdValid;
}

export const purchaseOrderRequired = (value) => {
    let isPurchaseOrderValid = false;
    if(value === '') {
        isPurchaseOrderValid = true;
    }
    return isPurchaseOrderValid;
}

export const positionIdRequired = (value) => {
    let isPositionIdValid = false;
    if(value === '') {
        isPositionIdValid = true;
    }
    return isPositionIdValid;
}

export const worklocationRequired = (value) => {
    let isworkLocationValid = false;
    if(value === 'Please Select') {
        isworkLocationValid = true;
    }
    return isworkLocationValid;
}

export const floorRequired = (value) => {
    let isfloorValid = false;
    if(value === 'Please Select') {
        isfloorValid = true;
    }
    return isfloorValid;
}

export const seatTypeRequired = (value) => {
    let isSeatTypeValid = false;
    if(value === '') {
        isSeatTypeValid = true;
    }
    return isSeatTypeValid;
}

export const seatNumberRequired = (value) => {
    let isSeatNumberValid = false;
    if(value === '') {
        isSeatNumberValid = true;
    }
    return isSeatNumberValid;
}

export const occupiedRequired = (value) => {
    let isOccupiedValid = false;
    if(value === 'Please Select') {
        isOccupiedValid = true;
    }
    return isOccupiedValid;
}

export const shiftTimingsRequired = (value) => {
    let isShitTimingsValid = false;
    if(value === 'Please Select') {
        isShitTimingsValid = true;
    }
    return isShitTimingsValid;
}

export const vendorNameRequired = (value) => {
    let isVendorNameValid = false;
    if(value === 'Please Select') {
        isVendorNameValid = true;
    }
    return isVendorNameValid;
}

export const vendorEmpIdRequired = (value) => {
    let isVendorEmpIdValid = false;
    if(value === '') {
        isVendorEmpIdValid = true;
    }
    return isVendorEmpIdValid;
}

export const vendorEmailRequired = (value) => {
    let isVendorEmailValid = false;
    if(value === '') {
        isVendorEmailValid = true;
    }
    return isVendorEmailValid;
}

export const vendorUnitRequired = (value) => {
    let isVendorUnitValid = false;
    if(value === 'Please Select') {
        isVendorUnitValid = true;
    }
    return isVendorUnitValid;
}

export const empHidRequired = (value) => {
    let isEmpHidValid = false;
    if(value === '') {
        isEmpHidValid = true;
    }
    return isEmpHidValid;
}

export const headSetSerialRequired = (value) => {
    let isHeadSetSerialValid = false;
    if(value === '') {
        isHeadSetSerialValid = true;
    }
    return isHeadSetSerialValid;
}

export const headSetMakeRequired = (value) => {
    let isHeadSetMakeValid = false;
    if(value === '') {
        isHeadSetMakeValid = true;
    }
    return isHeadSetMakeValid;
}

export const headSetModelRequired = (value) => {
    let isHeadSetModelValid = false;
    if(value === '') {
        isHeadSetModelValid = true;
    }
    return isHeadSetModelValid;
}

export const assetSerialRequired = (value) => {
    let isAssetSerailValid = false;
    if(value === '') {
        isAssetSerailValid = true;
    }
    return isAssetSerailValid;
}

export const assetMakeRequired = (value) => {
    let isAssetMakeValid = false;
    if(value === '') {
        isAssetMakeValid = true;
    }
    return isAssetMakeValid;
}

export const assetModelRequired = (value) => {
    let isAssetModelValid = false;
    if(value === '') {
        isAssetModelValid = true;
    }
    return isAssetModelValid;
}



/* eslint-disable no-unused-vars */
import React from "react";
import { Route, Switch } from "react-router-dom";
import Dashboard from './Modules/Dashboard/Components/Dashboard';
import Home from './Modules/Home/Components/Home';
import DashboardLayout from './SharedModules/Layout/Components/DashboardLayout';
import KnowledgeMangement from './Modules/KnowledgeMangement/LandingPage';
import KnowledgeMangementViewAll from './Modules/KnowledgeMangement/KnowledgeArtifacts/KAViewMore';
import KnowledgeMangementCreate from './Modules/KnowledgeMangement/KnowledgeArtifacts/KACreate';
import EmployeeForm from './Modules/Resource/Components/employeeDetails/EmployeeForm';
import Resource from './Modules/Resource/Components/LandingPage/Resource';
import EventsNews from './Modules/EventsAndNews/Components/EventsNews';
import Reports from './Modules/Reports/Components/TabPanel/MainTabPanel';
import NavigationMenu from './SharedModules/Navigation/NavigationMenu';
import TopNavigation from './SharedModules/Layout/Components/TopNavigation';
import AccountManagement from './Modules/AccountManagement/Components/AccountManagement';
export default function RoutesApp(props) {
  return (
    <React.Fragment>
      <Switch>
      <Route exact path="/" component={Home} />
      <Route exact path="/projectDashboard" component={Dashboard} />
      <Route exact path="/dashboardLayout" component={DashboardLayout} />
      <Route path='/knowledgeManagement' component={KnowledgeMangement} />
      <Route path='/KAViewMore' component={KnowledgeMangementViewAll} />
      <Route path='/KACreate' component={KnowledgeMangementCreate} />
      <Route exact path = "/employee" component = {EmployeeForm} />
      <Route exact path = "/talentManagement" component = {Resource} />
      <Route exact path="/eventsNews" component={EventsNews} />
      <Route exact path = "/reportManagement" component = {Reports} />
      <Route exact path = "/navigationMenu" component = {NavigationMenu} />
      <Route exact path = "/AccountManagement" component = {AccountManagement} />
      </Switch>
    </React.Fragment>
  );
}

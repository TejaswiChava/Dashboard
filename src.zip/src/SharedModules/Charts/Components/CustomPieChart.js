import React from 'react';
import PieChart, {
  Series,
  Label,
  Connector,
  Size,
  Export
} from 'devextreme-react/pie-chart';

// import { areas } from './data.js';

export default function CustomPieChart(props) {

  const pointClickHandler = (e) => toggleVisibility(e.target);

  const legendClickHandler = (e) => {
    let arg = e.target;
    let item = e.component.getAllSeries()[0].getPointsByArg(arg)[0];

    this.toggleVisibility(item);
  }

  const toggleVisibility = (item) => {
    item.isVisible() ? item.hide() : item.show();
  }

  return (
    <PieChart
      id="pie"
      dataSource={props.dataSource}
      // palette="Bright"
      palette="Soft Pastel"
      title={props.title}
      onPointClick={pointClickHandler}
      onLegendClick={legendClickHandler}
    >
      <Series
        argumentField="country"
        valueField="area"
      >
        <Label visible={true}>
          <Connector visible={true} width={1} />
        </Label>
      </Series>

      <Export enabled={true} />
    </PieChart>
  );
}

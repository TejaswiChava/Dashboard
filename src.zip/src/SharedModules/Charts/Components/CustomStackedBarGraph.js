import React from 'react';

import { Chart, Series, CommonSeriesSettings, Legend, ValueAxis, Title, Export, Tooltip } from 'devextreme-react/chart';

import { maleAgeData } from './data.js';

export default function CustomStackedBarGraph(props) {
  const customizeTooltip = (arg) => {
    return {
      text: `${arg.seriesName } hours: ${ arg.valueText}`
    };
  }

  return (
    <Chart
        id="chart"
        palette="pastel"
        title={props.title}
        dataSource={props.dataSource}
      >
        <CommonSeriesSettings argumentField="state" type="stackedBar" />
        <Series
          valueField="completed"
          name="Completed Effort"
        />
        <Series
          valueField="remaining"
          name="Remaining Effort"
        />
        {/* <Series
          valueField="older"
          name="65 and older"
        /> */}
        <ValueAxis position="right">
          <Title text="hours" />
        </ValueAxis>
        <Legend
          verticalAlignment="bottom"
          horizontalAlignment="center"
          itemTextPosition="top"
        />
        <Export enabled={true} />
        <Tooltip
          enabled={true}
          location="edge"
          customizeTooltip={customizeTooltip}
        />
      </Chart>
  );
}

import React from 'react';
import { Widget, addResponseMessage, addLinkSnippet, toggleWidget, renderCustomComponent } from 'react-chat-widget';
import 'react-chat-widget/lib/styles.css';
import ToDoOptions from './ToDoOptions';
 

class Chatbot extends React.Component {

  componentDidMount() {

    addResponseMessage("Welcome to Conduent! How may I help you?");

    renderCustomComponent(ToDoOptions);

    toggleWidget();

  }

 

  handleNewUserMessage = (newMessage) => {

    const lowerCaseMessage = newMessage.toLowerCase()

 

    if ((lowerCaseMessage.includes("hello") && lowerCaseMessage.indexOf("hello") === 0)

     || (lowerCaseMessage.includes("hi") && lowerCaseMessage.indexOf("hi") === 0)) {

        addResponseMessage("Hi, friend.");

    } else if (lowerCaseMessage.includes("get lost")) {

        addResponseMessage("Oh, I would try that but I'm finding it really difficult to do.");

    } else if (lowerCaseMessage.includes("good morning") || lowerCaseMessage.includes("good noon") ||

    lowerCaseMessage.includes("good afternoon") || lowerCaseMessage.includes("good evening") ||

    lowerCaseMessage.includes("good night")) {

      var today = new Date();

      let time = today.getHours();

      if(time < 12){

        addResponseMessage("Good morning, have a great day ahead!");

      } else if(time >= 12 && time < 16){

        addResponseMessage("Good afternoon, don't forget to have your lunch.");

      } else if(time >= 16 && time < 20){

        addResponseMessage("Good evening");

      } else if (time >= 20){

        addResponseMessage("Good night. Drive home safely!");

      }

    } else if (lowerCaseMessage.includes("how are you")) {

        addResponseMessage("I am fine, thank you!");

    } else if (lowerCaseMessage.includes("thank you") || lowerCaseMessage.includes("thanks")) {

      addResponseMessage("Happy to help you.");

    } else if (lowerCaseMessage.includes("something about conduent") || lowerCaseMessage.includes("what does conduent do")) {

      addResponseMessage("We deliver mission-critical services and solutions on behalf of businesses and governments – creating exceptional outcomes for our clients and the millions of people who count on them. Conduent’s vision is to become the leading business services partner for companies and governments worldwide.");

    } else if (lowerCaseMessage.includes("alexa") || lowerCaseMessage.includes("google assistant")

    || lowerCaseMessage.includes("siri") || lowerCaseMessage.includes("bixby"))  {

      addResponseMessage("Well we majored on the same subjects.");

    } else if (lowerCaseMessage.includes("old are you") || lowerCaseMessage.includes("your age")) {

      addResponseMessage("Well, that's a secret no one will ever know.");

    } else if (lowerCaseMessage.includes("weather") || lowerCaseMessage.includes("restaurants")) {

        addResponseMessage("You might as well google it!");

    } else if (lowerCaseMessage.includes("who are you") || lowerCaseMessage.includes("name")) {

        addResponseMessage("I am Blizzard!, your assistant.");

    } else if (lowerCaseMessage.includes("tell me something about yourself")) {

      addResponseMessage("I am Blizzard. I am here to facilitate your tasks on the application. I can provide you any information that you are looking for in our application or aleast redirect you to the correct source.");

    } else if (lowerCaseMessage.includes("knowledge")) {

        let link = {

            title: 'Your source to all knowledge',

            link: 'https://www.google.com',

            target: '_blank'

        }

        addLinkSnippet(link);

    } else if (lowerCaseMessage.includes("what can i do here")) {

      renderCustomComponent(ToDoOptions);

    } else {

        addResponseMessage("I am sorry I did not get that.");

    }

  }

 

  render() {

    return ( 

      <div>
        <Widget handleNewUserMessage = { this.handleNewUserMessage }
        title = "Blizzard"
        subtitle = "Here to help you." />
        </div>
    );

  }

}
export default Chatbot;
import React from "react";

import "./Chatbot.scss";
 

const ToDoOptions = (props) => {

  const options = [

    { text: "Project Management", handler: "/projectDashboard", id: 1 },

    { text: "Knowledge Management", handler: "/knowledgeManagement", id: 2 },

    { text: "Talent Management", handler: "/talentManagement", id: 3 },

    { text: "Report Creation", handler: "/reportManagement", id: 4 },

    // { text: "Interview prep", handler: "https://www.google.com/", id: 5 },

  ];

 

  const optionsMarkup = options.map((option) => (

    <a

      className="toDo-option-button"

      key={option.id}

      href={option.handler}

      target="_blank"

      rel="noopener noreferrer"

    >

      {option.text}

    </a>

  ));

 

  return (

    <div className="msg-styles">

        <p className="msg">Here is a list of things you can do on our website!</p>

        <div className="toDo-options-container">{optionsMarkup}</div>

    </div>

  );

};

 

export default ToDoOptions;
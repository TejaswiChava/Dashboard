import React from 'react';
import '../../Layout/Layout.scss';
import Routes from '../../../Routes';
import TopNavigation from './TopNavigation';

export default function Layout() {
    return (
      <div className='main-container'>
        {/* <TopNavigation/> */}
        <div className='body-container'>
          <Routes/>
        </div>
      </div>
    );
  }
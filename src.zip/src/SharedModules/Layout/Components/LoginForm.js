import React from "react";
import Avatar from "@material-ui/core/Avatar";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import TextField from "@material-ui/core/TextField";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Link from "@material-ui/core/Link";
import Grid from "@material-ui/core/Grid";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";
import InputAdornment from "@material-ui/core/InputAdornment";
import AccountCircle from "@material-ui/icons/AccountCircle";
import LockIcon from "@material-ui/icons/Lock";
import IconButton from "@material-ui/core/IconButton";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";

export default function SignIn() {
  const [userCredentials, setUserCredentials] = React.useState({
    userName: "",
    password: "",
    showPassword: false
  });
  const userCredentialsHandleChange = (name) => (event) => {
    setUserCredentials({ ...userCredentials, [name]: event.target.value });
  };
  const handleClickShowPassword = () => {
    setUserCredentials({
      ...userCredentials,
      showPassword: !userCredentials.showPassword
    });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };
  return (
    <Container id="loginDialog" component="main" maxWidth="xs">
      <CssBaseline />
      <div className="paper">
        <Avatar className="avatar">
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Login
        </Typography>
        <form className="form" noValidate>
          <div className="formElement">
            <TextField
              required
              fullWidth
              id="input-with-icon-textfield"
              label="UserName"
              type="text"
              value={userCredentials.userName}
              onChange={userCredentialsHandleChange("userName")}
              defaultValue="Username"
              autoFocus
              inputProps={{
                minLength: 6,
                maxLength: 16,
                style: { textTransform: "uppercase" }
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <AccountCircle />
                  </InputAdornment>
                )
              }}
            />
          </div>
          <div className="formElement">
            <TextField
              id="standard-adornment-Password"
              label="Password"
              fullWidth
              required
              value={userCredentials.password}
              onChange={userCredentialsHandleChange("password")}
              type={userCredentials.showPassword ? "text" : "password"}
              inputProps={{ maxLength: 15 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockIcon />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      onMouseDown={handleMouseDownPassword}
                    >
                      {userCredentials.showPassword ? (
                        <Visibility />
                      ) : (
                        <VisibilityOff />
                      )}
                    </IconButton>
                  </InputAdornment>
                )
              }}
            />
          </div>

          <FormControlLabel
            control={<Checkbox value="remember" color="primary" />}
            label="Remember me"
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className="submit"
          >
            Sign In
          </Button>
          <Grid container>
            <Grid item xs>
              <Link href="#" variant="body2">
                Forgot password?
              </Link>
            </Grid>
            <Grid item>
              <Link href="#" variant="body2">
                {"Sign Up"}
                {/* Don't have an account?  */}
              </Link>
            </Grid>
          </Grid>
        </form>
      </div>
    </Container>
  );
}

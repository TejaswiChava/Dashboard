import React from 'react';
import '../../Layout/Layout.scss';
import {Button} from 'react-bootstrap';
import TextField from '@material-ui/core/TextField';
import InputAdornment from '@material-ui/core/InputAdornment';
import SearchIcon from '@material-ui/icons/Search';
import Dialog from '@material-ui/core/Dialog';
import Modal from './Modal';
import NavigationMenu from '../../Navigation/NavigationMenu';

function TopNavigation(props) {
    const [showModal, setShowModal] = React.useState(false);
    const closeModal = () => setShowModal(false);
    const openModal = () => setShowModal(true);
    const [open, setOpen] = React.useState(false);
    const [defaultLink, setDefaultLink] = React.useState('#home');
    const links = [
        { label: 'Home', link: '#home' },
        // { label: 'Projects', link: '#projects' },
        // { label: 'Reports', link: '#reports' },
        // { label: 'KM Activities', link: '#km-activities' },
        // { label: 'Quality', link: '#quality' }
      ];

    const linkList = links.map((link, index) => {
        const linkActive = (defaultLink === link.link) ? (
            <a className="menu-link-active" href={link.link}>{link.label}</a>
        ) : (
            <a className="menu-link" href={link.link} onClick={(e) => {setDefaultLink(link.link)}}>{link.label}</a>
        );
        return (
            <li key={index} className="menu-list-item">
                {linkActive}
            </li>
        );
    });
    console.log(props.isLoggedin);
    return (
        <div>
        { !props.isLoggedin ?
        <div>
            <nav className="menu">
                {/* <h3>
                    <span>AMP</span>
                    <span>lify</span>
                </h3> */}
                <a href="/"><img src='./amp_logo.png' alt='amplify logo'/></a>
                <div className="menu-right">
                    {/* <ul className="menu-list">
                        {linkList}
                    </ul>
                    <TextField 
                    className="menu-search-input" 
                    placeholder="Search here" 
                    InputProps={{
                        endAdornment: <InputAdornment position="end">
                            <SearchIcon
                                aria-label="search"
                            >
                            </SearchIcon>
                        </InputAdornment>
                    }}
                    />  */}
                    <Button className='btn-login' onClick={openModal}>LOGIN</Button>
                </div>
            </nav>
            {/* <Dialog className='login-form' open={open} disableBackdropClick>
                <form>
                <h6 className="text-center font-weight-bold my-3">Login</h6>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email address</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"/>
                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"/>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                        <label class="form-check-label" for="exampleCheck1">Check me out</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                
            </Dialog> */}
            <Modal show={showModal} close={closeModal} />
        </div> 
        :
        <div>
            {/* <nav className="menu">
                <a href="/"><img src='./amp_logo.png' alt='amplify logo'/></a>
                <div className="menu-right">
                </div>
            </nav> */}
            <NavigationMenu/>
        </div>}
        </div>
    );
}

export default TopNavigation;
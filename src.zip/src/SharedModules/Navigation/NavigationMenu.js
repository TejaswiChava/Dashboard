import React from 'react';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import CssBaseline from '@material-ui/core/CssBaseline';
import List from '@material-ui/core/List';
import { withRouter } from 'react-router-dom';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import { NavLink } from 'react-router-dom';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import Collapse from '@material-ui/core/Collapse';
import MenuIcon from '@material-ui/icons/Menu';
import FiberManualRecordRoundedIcon from '@material-ui/icons/FiberManualRecordRounded';

// import Routes from './Routes';
import { navStructure, getActivePath } from './navStructure';
import './Navigation.scss';

const Item = ({ navTo, value, icon = null, hasChildren = false, isSelected = true }) => {
  if (!hasChildren) {
    return (
      <>
        <NavLink className={isSelected ? "d-inline-flex" : "d-inline-flex"} to={navTo}>
          {icon && icon}
          <ListItemText primary={value} />
          {hasChildren ? isSelected ? < ExpandLess /> : <ExpandMore /> : null}
        </NavLink>
      </>
    )
  } else return (
    <>
      {icon && icon}
      <ListItemText primary={value} />
      {hasChildren ? isSelected ? < ExpandLess /> : <ExpandMore /> : null}
    </>
  )
}

class Menu extends React.Component {
  state = {
    selectedItems: []
  }
  selectActive = (id, nestLvl, isFolder) => {
    let _selectedItems = [...this.state.selectedItems];
    _selectedItems[nestLvl] !== id ? _selectedItems[nestLvl] = id : isFolder && _selectedItems.splice(nestLvl);
    _selectedItems.length > nestLvl && _selectedItems.splice(nestLvl + 1);
    this.setState({ selectedItems: _selectedItems });
  }
  rerenderActive(path) {
    let _selectedItems = getActivePath(path);
    this.setState({ selectedItems: _selectedItems || [] });
  }
  componentDidMount() {
    console.log(this.props.location)
    this.rerenderActive(this.props.location.pathname);
  }
  componentDidUpdate(prevProps) {
    if (prevProps.location.pathname !== this.props.location.pathname) {
      this.rerenderActive(this.props.location.pathname)
    }
  }
  renderSubMenu({ menuItems, nestedLevel = 0 }) {
    const MenuItems = menuItems.map((structure, i) => {
      let { drawerIsOpen, toggleDrawer } = this.props;
      let newNestedLevel = nestedLevel + 1;
      let isSelected = this.state.selectedItems[nestedLevel] === structure.id;
      const Item_1 = Item({ ...structure, nestedLevel, isSelected, ...this.props });
      let SubMenu = structure.hasChildren ? this.renderSubMenu({ menuItems: structure.children, nestedLevel: newNestedLevel }) : null;//&& isSelected
      return (
        <React.Fragment key={structure.id}>
          <ListItem button key={structure.value} className={isSelected ? 'highlighted-side-nav' : ''}
            id={structure.id}
            onClick={() => {
              !drawerIsOpen && toggleDrawer();
              this.selectActive(structure.id, nestedLevel, structure.hasChildren);
              !structure.hasChildren && this.rerenderActive(this.props.location.pathname);
            }}>
            {Item_1}
          </ListItem>
          <Collapse style={{ paddingLeft: 10 + nestedLevel * 8 }} in={isSelected && drawerIsOpen} >
            {SubMenu}
          </Collapse>
        </React.Fragment >
      )
    });

    return MenuItems
  }
  render() {
    return (
      <>
        <div className="sidebar-header">
          <div className="user-pic">
            <img className="img-responsive img-rounded" src="./user.jpg" alt='user' />
          </div>
          <div className="user-info">
            <div className="user-name">John <strong>Smith</strong>
            </div>
            <div className="user-role">Administrator</div>
            <div className="user-status">
              <FiberManualRecordRoundedIcon />
              <span>Online</span>
            </div>
          </div>
        </div>
        <List className="side-menu-list">
          {this.renderSubMenu({ menuItems: this.props.menuItems })}
        </List>
      </>
    )
  }
}

const getMainFrameSizing = (_ref) => {
  let mainContent = document.getElementById("mainContent");

  let header = document.getElementById("mainContentHeader"),
    footer = document.getElementById("mainContentFooter"),
    headerH = header ? header.getBoundingClientRect().bottom - header.getBoundingClientRect().top : 0,
    footerH = footer ? footer.getBoundingClientRect().bottom - footer.getBoundingClientRect().top : 0,
    mainContentBounds = mainContent ? mainContent.getBoundingClientRect() : null,
    mainContentH = 635,
    _minHeight = mainContentH ? mainContentH - headerH - footerH : 0;

  let _hasScroll = mainContent ? mainContent.scrollHeight !== mainContent.clientHeight : false;

  return { _minHeight, _hasScroll };
}

class MainFrame extends React.Component {
  state = {
    scrollbar: false,
    marginRightValue: 0,
    minHeight: 0,
    mainFrameRef: React.createRef()
  }
  timer = null;
  updateWithrateLimit = () => {
    if (this.timer) return;
    this.timer = setTimeout(() => {
      this.update();
      clearInterval(this.timer);
    }, 100);
  }
  update = () => {
    let { _minHeight, _hasScroll } = getMainFrameSizing();
    if (_hasScroll !== this.state.scrollbar) {
      this.setState({ scrollbar: _hasScroll });
    }
    if (_minHeight !== this.state.minHeight) {
      this.setState({ minHeight: _minHeight });
    }
  }
  observer;

  componentDidMount() {
    // this.setState({ marginRightValue: getMainScrollbarWidth(this.state.mainFrameRef) })
    this.observer = new MutationObserver(this.update);
    this.observer.observe(this.state.mainFrameRef.current, { attributes: true, childList: true, subtree: true });
  }
  componentDidUpdate() {
    this.updateWithrateLimit();
  }
  componentWillUnmount() {
    this.observer.disconnect()
  }
  render() {
    let { minHeight, mainFrameRef } = this.state;

    return (
      <>
        <div className="main-content has-scrollbar container-fluid" id="mainContent" style={{ marginRight: 0 }}>
          <div ref={mainFrameRef} style={{ minWidth: 500, height: '100%' }}>
            <div className="">
              <div className="row" id="mainContentHeader">
              </div>
            </div>
            {/* <Footer main /> */}
          </div>
        </div>
      </>
    );
  }
}
function NavigationMenu(props) {
  const [drawerIsOpen, setDrawerOpen] = React.useState(true);

  const toggleDrawer = () => {
    setDrawerOpen(!drawerIsOpen);
  };
  const handleDrawerOpen = () => {
    setDrawerOpen(true);
  };

  const onHamburgerClick = ev => {
    ev.stopPropagation();
    toggleDrawer()
  };

  return (
    <>
      <nav className="menu">
        <div className="menu-logo">
          <a href="/"><img src='./amp_logo.png' alt='amplify logo' /></a>
          <div className="d-inline">
            <button type="button" id="sidebarCollapse" className="btn" onClick={onHamburgerClick}>
              <MenuIcon onClick={onHamburgerClick} />
              <span className="sr-only">Toggle Menu</span>
            </button>
          </div>
        </div>
        <div className="menu-right">
        </div>
      </nav>
      <div className={!drawerIsOpen ? 'minimize-sidebar' : 'container-fluid p-0'}>
        <CssBaseline />
        <Drawer
          className='side-drawer'
          variant="permanent"
          anchor="left"
          open={drawerIsOpen}
        >


          <div className='p-4 pt-5'>
            <Menu
              menuItems={navStructure}
              toggleDrawer={toggleDrawer}
              drawerIsOpen={drawerIsOpen}
              location={props.location}
            />
            <div id='nav-footer'>
              <p className={drawerIsOpen ? 'text-muted' : 'd-none'}>
                Copyright &copy; {new Date().getFullYear()} All rights reserved
                </p>

            </div >
          </div>
        </Drawer>

        <MainFrame handleDrawerOpen={handleDrawerOpen} setLogOut={props.setLogOut} uuid={props.uuid} />

      </div >
    </>
  );
}

export default withRouter(NavigationMenu);
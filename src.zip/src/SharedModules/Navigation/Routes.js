// import React from 'react';
// import { Route } from 'react-router-dom';

// import Dashboard from '../../components/Dashboard/Dashboard'
// import AddEmployee from '../../components/rescource-management/employeeDetails/EmployeeForm';
// import Resource from '../../components/rescource-management/LandingPage';

// export default function RoutesApp (props) {
//     return (
//       <React.Fragment // uuid={props.uuid}
//       >
//         <Route exact path="/" component={Resource} />
//         <Route path="/AddEmployee" component={AddEmployee} />
//         <Route path="/dashboard" component={Dashboard} />
//     </React.Fragment>
//     );
// }
/* eslint-disable */
import React from 'react';
import BarChartIcon from "@material-ui/icons/BarChart";
import HomeIcon from '@material-ui/icons/Home';
import PeopleIcon from '@material-ui/icons/People';
import BookIcon from '@material-ui/icons/Book';
import AssignmentIcon from '@material-ui/icons/Assignment';
import './Navigation.scss';

const findTarget = (arr, target, path = [], nestedLvl = 0) => {
    for (let i = 0; i < arr.length; i++) {
        const newPath = [...path];
        newPath.push(arr[i].id);

        if (arr[i].navTo === target || (arr[i].hasAliases && arr[i].hasAliases.includes(target))) {
            return newPath;
        }

        if (arr[i].hasChildren) {
            const result = findTarget(arr[i].children, target, newPath, nestedLvl + 1);
            if (result) {
                return result;
            }
        }
    }
};

export const getActivePath = (urlPath, expandLvl) => {
    return findTarget(navStructure, urlPath, expandLvl);
};

const icons = {
    faChart: (<span className="sidebar-icon">
        {/* <i className="fa fa-bar-chart" aria-hidden = 'true'></i> */}
        <BarChartIcon/>
    </span>),
    faHome: (<span className="sidebar-icon">
        {/* <i class="fa fa-home" aria-hidden="true"></i> */}
        <HomeIcon/>
    </span>),
    faUsers: (<span className="sidebar-icon">
     {/* <i class="fa fa-users" aria-hidden="true"></i> */}
     <PeopleIcon/>
    </span>),
    faBlog: (<span className="sidebar-icon">
    {/* <i class="fa fa-pencil" aria-hidden="true"></i> */}
    <BookIcon/>
   </span>),
    faProjects: (<span className="sidebar-icon">
      {/* <i class="fa fa-laptop" aria-hidden="true"></i> */}
      <AssignmentIcon/>
    </span>)
};

const generateUUID = () => {
    var dt = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = (dt + Math.random() * 16) % 16 | 0;
      dt = Math.floor(dt / 16);
      return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return uuid;
  };



const dataToUrlParam = (rowData) => {
    const objStr = JSON.stringify(rowData);
    const toBase64 = btoa(objStr);
    return toBase64;
};


export const navStructure = [
    {
        value: "Dashboard",
        navTo: '/dashboard',
        icon: icons.faHome,
        id: generateUUID(),
        hasChildren: false,
        expanded: false
    },
    {
        value: "Projects",
        navTo: '/dashboard',
        icon: icons.faProjects,
        id: generateUUID(),
        hasChildren: false,
        expanded: false
    },
    {
        value: "Blogs",
        navTo: '/dashboard',
        icon: icons.faBlog,
        id: generateUUID(),
        hasChildren: false,
        expanded: false
    },
    {
        value: "Resource",
        navTo: '/dashboard',
        icon: icons.faUsers,
        id: generateUUID(),
        hasChildren: false,
        expanded: false
    },
    {
        value: 'Reports',
        id: generateUUID(),
        hasAliases: ['/Reports'],
        icon: icons.faChart,
        hasChildren: true,
        expanded: false,
        children: [
            {
                value: 'Project Reports',
                id: generateUUID(),
                navTo: '/projectreports',
                hasChildren: false
            },
            {
                value: 'Unit Reports',
                id: generateUUID(),
                navTo: '/unitreports',
                hasChildren: false
            }
        ]
    }
]


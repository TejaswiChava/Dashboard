/* eslint-disable no-unused-vars */
import React, { useEffect } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableFooter from '@material-ui/core/TableFooter';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import { withRouter } from 'react-router';
import EnhancedTableHead from './EnhancedTableHead';
import TablePaginationActions from './TablePagination';
import { desc, stableSort, getSorting } from './TableSort';
import moment from 'moment';
import Bootstrap, { Button } from 'react-bootstrap';
import Moment from 'react-moment';
import numeral from 'numeral';
import Radio from '@material-ui/core/Radio';
import Checkbox from '@material-ui/core/Checkbox';
import { Link } from 'react-router-dom';import LinearProgress from '@material-ui/core/LinearProgress';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import '../Table.scss';

function LinearProgressWithLabel(props) {
  return (
    <Box display="flex" alignItems="center">
      <Box width="100%" mr={1}>
        <LinearProgress variant="determinate" {...props} />
      </Box>
      <Box minWidth={35}>
        <Typography variant="body2" color="textSecondary">{`${
          props.value}%`}</Typography>
      </Box>
    </Box>
  );
}
function TableComponent(props) {
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState(props.defaultSortColumn);
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [varCharFlag, setvarCharFlag] = React.useState(false);
  const [showHeaderCheckBox, setShowHeaderCheckBox] = React.useState(false);
  const rowClick = row => event =>{
    props.onTableRowClick(row);
  }

  useEffect(() => {
    setPage(0);
    selected.length !== 0 && setSelected([]);
    if (props.sortOrder !== undefined) {
      setOrder(props.sortOrder);
    }
    props.headCells.map(var1 => {
      if (var1.id === props.defaultSortColumn) {
        if (var1.isVarChar) {
          setvarCharFlag(true);
        } else {
          setvarCharFlag(false);
        }
      }
    });
    if (props.defaultSortColumnDesc) {
      setOrder('desc')
    }
    let countWithID = 0;
    props.tableData.map((values) => {
      if (values.id) {
        countWithID++;
      }
    })
    if (countWithID > 0) {
      setShowHeaderCheckBox(true);
    } else {
      setShowHeaderCheckBox(false);
    }
  }, [props.tableData]);

  useEffect(() => {
    let countWithID = 0;
    props.tableData.map((values) => {
      if (values.id) {
        countWithID++;
      }
    })
    if (countWithID > 0) {
      setShowHeaderCheckBox(true);
    } else {
      setShowHeaderCheckBox(false);
    }
  }, [props.tableData.length]);

  useEffect(() => {
    if (!props.isSearch && props.isSearch !== undefined) {
      props.onTableRowDelete(selected);
    }
  }, [selected]);

  const handleRequestSort = (event, property) => {
    const isDesc = orderBy === property && order === 'desc';
    setOrder(isDesc ? 'asc' : 'desc');
    setOrderBy(property);
    props.headCells.map(var1 => {
      if (var1.id === property) {
        if (var1.isVarChar) {
          setvarCharFlag(true);
        } else {
          setvarCharFlag(false);
        }
      }
    });
  };

  const handleSelectAllClick = event => {
    if (event.target.checked) {
      const newSelecteds = props.tableData.map(n => n.id);
      let tempSelects = JSON.parse(JSON.stringify(newSelecteds));
      setSelected(tempSelects);
      return;
    }
    setSelected([]);
  };
  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    }else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
      );
    }

    setSelected(newSelected);
  };
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const formatTableCell = (row, name, index, labelId, rowIndex) => {
    if(name.isDate){
      return (
        <TableCell key={index} style={{ width: name.width }}>
          {moment(new Date(row[name.id])).format('L')}
        </TableCell>
      );
    }
    if(name.isBalance){
      return (
        <TableCell key={index} style={{ width: name.width }}>
          {numeral(row[name.id]).format('0,0.00')}
        </TableCell>
      );
    }
    if(name.isPercent){
      return (
        <TableCell key={index} style={{ width: name.width }}>
          {`${row[name.id]}%`}
        </TableCell>
      );
    }
    if(name.isProgress){
      return (
        <TableCell key={index} style={{ width: name.width }}>
          <LinearProgressWithLabel value={row[name.id]} />
        </TableCell>
      );
    }
    return (
      <TableCell key={index} style={{ width: name.width }}>
        {row[name.id]}
      </TableCell>
    );
  };
  const isSelected = name => selected.indexOf(name) !== -1;

  const emptyRows =
    rowsPerPage -
    Math.min(rowsPerPage, props.tableData.length - page * rowsPerPage);
  const tableRows = props.tableRows;
  const [selectedID, setSelectedID] = React.useState(null);
  return (
    <div className={'pos-relative'}>
      <div className="table-responsive" id="style-2">
        <Table
          className="table"
          aria-label="enhanced table"
        >
          <EnhancedTableHead
            numSelected={selected.length}
            order={order}
            orderBy={orderBy}
            onSelectAllClick={handleSelectAllClick}
            onRequestSort={handleRequestSort}
            rowCount={props.tableData.length}
            headCells={props.headCells}
            isSearch={props.isSearch}
            showHeaderCheckBox={showHeaderCheckBox}
          />
          <TableBody>
            {props.tableData && stableSort(props.tableData, getSorting(order, orderBy, varCharFlag))
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, index) => {
                const isItemSelected = isSelected(row.id);
                const labelId = `enhanced-table-checkbox-${index}`;
                return (
                  <TableRow
                    hover
                    onClick={rowClick(row)}
                    role="checkbox"
                    aria-checked={isItemSelected}
                    tabIndex={-1}
                    key={row.id || '01' + index || '01'}
                    selected={isItemSelected}
                  >
                    {!props.isSearch && (row.id || row.uuId) && !row.isChild ? (
                      <TableCell padding="checkbox">
                        <Checkbox
                          checked={isItemSelected}
                          color="primary"
                          inputProps={{ 'aria-labelledby': labelId }}
                          onClick={event =>
                            handleClick(event, row.id ? row.id : index)
                          }
                        />
                      </TableCell>
                    ) : null}
                    <TableCell
                      id={labelId}
                      hidden={true}
                      scope="row"
                      padding="default"
                    >
                      {index}
                    </TableCell>
                    {row.id ? (
                      <TableCell
                        id={labelId}
                        hidden={true}
                        scope="row"
                        padding="default"
                      >
                        {row.id}
                      </TableCell>
                    ) : null}
                    {props.headCells.map((name, colindex) =>
                      formatTableCell(row, name, colindex, labelId, index)
                    )}
                  </TableRow>)
                ;
              })}
            {emptyRows > 0 && (
              <TableRow>
                <TableCell colSpan={props.headCells.length} />
              </TableRow>
            )}
          </TableBody>
          <TableFooter className="hide-on-print" >
            <TableRow >
              <TableCell className="table-pagination">Page: <span>{page + 1}</span></TableCell>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                colSpan={props.headCells.length}
                count={props.tableData.length}
                rowsPerPage={rowsPerPage}
                page={page}
                SelectProps={{
                  inputProps: { 'aria-label': 'rows per page' },
                  native: true
                }}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeRowsPerPage}
                ActionsComponent={TablePaginationActions}
              />
            </TableRow>
          </TableFooter>
        </Table>
      </div>
    </div>
  );
}
export default TableComponent;
